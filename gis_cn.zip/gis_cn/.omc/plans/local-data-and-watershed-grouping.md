# Work Plan: 로컬 데이터 입력 + 유역합성 기능 (v3 — Final)

## Context

### Original Request
GIS CN값 계산기 QGIS 플러그인에 두 가지 신규 기능 추가:
1. **로컬 데이터 입력 기능**: 토양군/토지피복도를 PostGIS DB 대신 로컬 SHP/GPKG 파일에서 불러오기
2. **유역합성(Watershed Grouping) 기능**: 다수 소유역을 그룹핑하여 합성 CN값 계산

### Research Findings

**현재 아키텍처 분석:**
- `CnWorker.run()` (dialog.py L292-343): 4단계 파이프라인이 모두 PostGIS 의존
  - Step 1-3: `db_manager.py`의 `get_soil_layer()`, `get_land_cover_layer()`, `get_soil_lc_intersection()` 호출
  - Step 4: QGIS `native:intersection` (이 단계만 로컬)
- `spatial_ops.py`에 이미 `clip_layer()`, `dissolve_land_cover()`, `intersect_layers()` 함수가 존재하나 현재 미사용 (PostGIS로 대체됨). 로컬 모드에서 이들을 재활용 가능
- `result_calculator.py`의 `calculate_results()`: 소유역명 기준 그룹핑만 수행. 유역합성 로직 없음
- `land_use_mapper.py` 패턴: JSON 파일로 매핑 저장/로드 - 유역합성 그룹 정의도 동일 패턴 적용 가능

**UI 구조:**
- Tab 0 (레이어 불러오기): `rbFile`/`rbLayer` 라디오버튼은 소유역 입력 전환용 (토양군/토지피복 소스 전환이 아님)
- Tab 3 (CN값 계산): `_apply_cn_calc()` → `_export_results()` 순서로 실행
- 동적 탭 삽입 패턴: `_setup_mapping_tab()`이 Tab 1을 `insertTab()`으로 동적 생성 - 유역합성 탭도 동일 방식 가능

### Revision Notes (v2)
Critic의 4개 Critical + 4개 Minor 이슈 반영. Architect 권고 2건(헬퍼 추출, 자동 컬럼 감지) 채택.

---

## Work Objectives

### Core Objective
기존 PostGIS-only 워크플로우를 유지하면서, (1) 로컬 파일 기반 대안 경로를 추가하고, (2) 소유역 그룹핑을 통한 합성 CN값 계산 기능을 구현한다.

### Deliverables
1. Tab 0에 데이터 소스 선택 UI (DB vs 로컬) + 로컬 파일 브라우저 (토양군, 토지피복도)
2. `CnWorker`에 로컬 파일 기반 처리 경로 (QGIS Processing 사용)
3. 유역합성 관리 모듈 (`core/watershed_group.py`) + JSON 저장/로드
4. 유역합성 설정 카드를 **Tab 3 (CN값 계산) 내부에 삽입** (새 탭 추가 없음)
5. `result_calculator.py`에 헬퍼 추출 + 그룹별 합성 CN 계산 로직
6. `results.xlsx`에 개별 + 합성 결과 모두 포함

### Definition of Done
- [x] DB 모드: 기존 워크플로우 변경 없이 정상 동작
- [x] 로컬 모드: SHP/GPKG 토양군+토지피복도 파일로 전체 파이프라인 실행 가능
- [x] 로컬 모드: 한국어 컬럼명(수문학토양군 등) 자동 감지 + canonical 매핑
- [x] 유역합성: 그룹 정의 → 저장 → CN값 계산 시 합성 결과 포함
- [x] results.xlsx: 개별 소유역 + 합성 유역 결과 모두 출력
- [x] 한국어 UI 라벨 일관성 유지

---

## Must Have / Must NOT Have (Guardrails)

### MUST Have
- DB 모드와 로컬 모드 간 완전한 독립성 (하나가 실패해도 다른 쪽 영향 없음)
- 로컬 파일 컬럼 자동 감지: `SOIL_COLUMN_ALIASES` / `LC_COLUMN_ALIASES` 기반 auto-detect + ValidationError 폴백
- 유역합성 그룹 정의의 영속성 (JSON 파일 저장)
- 기존 `core/` 모듈의 public API 호환성 유지 (`calculate_results()` 시그니처 불변)
- `export_results()` 신규 파라미터는 keyword-only + None 기본값

### MUST NOT Have
- DB 연결 정보 변경 또는 새로운 DB 스키마
- 기존 4탭 구조 파괴 (Tab 3 내부에 카드 삽입만 허용, 탭 추가 없음)
- 하드코딩된 컬럼명 변경 (hydro_type, l1_code, l1_name 등 — canonical 이름은 유지)
- 로컬 모드에서 PostGIS 의존성
- 컬럼 매핑 UI (auto-detect로 충분, UI 과잉 복잡화 방지)

---

## Task Flow and Dependencies

```
[Task 1] core/local_data_handler.py 신규 생성 (컬럼 자동 감지 포함)
    ↓
[Task 2] CnWorker에 로컬 모드 분기 추가 (dialog.py)
    ↓
[Task 3] Tab 0 UI에 데이터 소스 선택 위젯 추가 (dialog.py)
    ↓
[Task 4] core/watershed_group.py 신규 생성
    ↓
[Task 5] 유역합성 설정 카드를 Tab 3 내부에 삽입 (dialog.py)
    ↓
[Task 6] result_calculator.py 헬퍼 추출 + 합성 CN 계산 로직 추가
    ↓
[Task 7] results.xlsx 출력에 합성 결과 포함
    ↓
[Task 8] dialog.py 통합 및 워크플로우 연결 + 테스트 시나리오
```

**병렬화 가능:**
- Task 1-3 (로컬 데이터) 과 Task 4-5 (유역합성 UI)는 독립적으로 병렬 진행 가능
- Task 6-7은 Task 4-5 완료 후 진행

---

## Detailed TODOs

### Task 1: core/local_data_handler.py 신규 생성
**Priority:** HIGH | **Complexity:** MEDIUM

로컬 SHP/GPKG 파일을 읽어서 DB에서 반환하는 것과 동일한 구조의 메모리 레이어를 반환하는 모듈.
**컬럼 자동 감지 + canonical 리네이밍 로직 포함** (Architect 권고 Q2 Option C 채택).

**Acceptance Criteria:**
- `load_local_soil(file_path, clip_layer)` → `QgsVectorLayer` (토양군_clip과 동일 구조, canonical 컬럼명)
- `load_local_land_cover(file_path, clip_layer, level)` → `QgsVectorLayer` (토지피복도_clip과 동일 구조, canonical 컬럼명)
- `get_local_soil_lc_intersection(soil_layer, lc_layer, level)` → `QgsVectorLayer` (토양군_토지피복_교차와 동일 구조)
- 컬럼 자동 감지: `_resolve_columns()` 함수로 한국어 변형 컬럼명 자동 매핑
- 감지 실패 시 `ValidationError` 발생 + 기대 컬럼명 vs 실제 컬럼명 목록을 한국어로 제공
- canonical 컬럼 리네이밍은 `local_data_handler` 내부에서 수행 → `spatial_ops`에는 canonical 이름만 전달

**Implementation Notes:**

#### 컬럼 자동 감지 (Critical Issue #1 해결)

한국 정부 배포 SHP 파일은 DB 컬럼명과 다른 이름을 사용한다. 자동 감지 + 리네이밍으로 해결.

```python
# 알려진 한국어 변형 → canonical 이름 매핑
SOIL_COLUMN_ALIASES = {
    'hydro_type': ['hydro_type', 'HYDRO_TYPE', '수문학토양군', '토양군', 'HSG', 'hsg'],
}

LC_COLUMN_ALIASES = {
    'l1_code': ['l1_code', 'L1_CODE', '대분류코드', '대분류_코드'],
    'l1_name': ['l1_name', 'L1_NAME', '대분류명', '대분류_명'],
    'l2_code': ['l2_code', 'L2_CODE', '중분류코드', '중분류_코드'],
    'l2_name': ['l2_name', 'L2_NAME', '중분류명', '중분류_명'],
    'l3_code': ['l3_code', 'L3_CODE', '세분류코드', '세분류_코드'],
    'l3_name': ['l3_name', 'L3_NAME', '세분류명', '세분류_명'],
}

def _resolve_columns(layer: QgsVectorLayer, alias_map: dict) -> dict:
    """
    레이어 필드에서 canonical 컬럼명 매핑을 자동 감지.
    반환: {canonical_name: actual_field_name} (예: {'hydro_type': '수문학토양군'})
    감지 실패 시 ValidationError (기대 vs 실제 컬럼 목록 포함).
    """
    field_names = [f.name() for f in layer.fields()]
    resolved = {}
    missing = []
    for canonical, aliases in alias_map.items():
        found = None
        for alias in aliases:
            if alias in field_names:
                found = alias
                break
        if found:
            resolved[canonical] = found
        else:
            missing.append(canonical)
    if missing:
        raise ValidationError(
            f"필수 컬럼을 찾을 수 없습니다.\n"
            f"기대 컬럼: {missing}\n"
            f"실제 컬럼: {field_names}\n"
            f"지원되는 이름: {[a for m in missing for a in alias_map[m]]}"
        )
    return resolved

def _rename_columns(layer: QgsVectorLayer, column_map: dict) -> QgsVectorLayer:
    """
    actual → canonical 리네이밍. 메모리 레이어로 복사하며 컬럼명 변경.
    column_map: {canonical_name: actual_field_name} (_resolve_columns 반환값)

    최적화: 모든 canonical == actual이면 원본 레이어를 그대로 반환 (복사 없음).
    부분 불일치 시에만 메모리 레이어를 생성하여 필드명 변경.

    구현 순서:
    1. column_map에서 canonical != actual인 항목이 있는지 확인
    2. 전부 동일하면 → return layer (복사 없음)
    3. 차이 있으면 → QgsVectorLayer('Polygon?crs=...') 메모리 레이어 생성
       - QgsFields 구성: actual 이름을 canonical 이름으로 교체
       - 원본 피처 순회 → geometry 복사 + attribute 값은 actual index에서 읽어 canonical index에 대입
    """
```

#### 함수 시그니처 (Critical Issue #2 해결)

`clip_layer()`는 `QgsVectorLayer` mask를 받으므로, 로컬 모드 함수도 모두 `QgsVectorLayer`를 받는다.
`clip_wkt` (string) 파라미터는 사용하지 않음 — DB 모드 전용.

```python
def load_local_soil(file_path: str, clip_layer: QgsVectorLayer) -> QgsVectorLayer:
    """
    로컬 토양군 파일 로드 → 컬럼 자동 감지 → canonical 리네이밍 → clip_layer로 Clip.
    반환: canonical 컬럼명 (hydro_type 등)을 가진 클립된 레이어.
    """

def load_local_land_cover(file_path: str, clip_layer: QgsVectorLayer,
                          level: str) -> QgsVectorLayer:
    """
    로컬 토지피복도 파일 로드 → 컬럼 자동 감지 → canonical 리네이밍 → Clip → Dissolve.
    반환: canonical 컬럼명 (l1_code, l1_name 등)을 가진 클립+디졸브된 레이어.
    """

def get_local_soil_lc_intersection(soil_layer: QgsVectorLayer,
                                    lc_layer: QgsVectorLayer,
                                    level: str) -> QgsVectorLayer:
    """
    이미 canonical 리네이밍된 토양군 × 토지피복도 Intersection.
    soil_layer, lc_layer는 load_local_soil/load_local_land_cover의 반환값.
    spatial_ops.intersect_layers() 재활용.
    """
```

처리 순서:
1. Load → `_resolve_columns()` → `_rename_columns()` (canonical 리네이밍)
2. `spatial_ops.clip_layer(renamed_layer, clip_layer, name)` (Clip)
3. `spatial_ops.dissolve_land_cover(clipped, level)` (토지피복도만, l3 제외)
4. `spatial_ops.intersect_layers(soil_clipped, lc_clipped, name)` (Intersection)

**핵심:** 컬럼 리네이밍은 `local_data_handler` 내부에서만 수행. `spatial_ops`는 항상 canonical 컬럼명을 기대하며 변경 불필요.

---

### Task 2: CnWorker에 로컬 모드 분기 추가
**Priority:** HIGH | **Complexity:** MEDIUM | **Depends on:** Task 1

`CnWorker.__init__()`에 `data_source` 파라미터 추가, `run()` 메서드에 분기 로직 삽입.

**Acceptance Criteria:**
- `CnWorker(input_layer, name_field, level, data_source='db', soil_path=None, lc_path=None)`
- `data_source='db'`: 기존 로직 그대로 (변경 없음)
- `data_source='local'`: `local_data_handler.py` 함수 호출
- 두 모드 모두 동일한 시그널 발행 (`progress`, `layer_ready`, `finished`, `error`)
- 로컬 모드 진행률 메시지: "① 로컬 토양군 Clip 중...", "② 로컬 토지피복도 Clip 중..." 등

**Implementation Notes:**

로컬 모드에서는 `clip_wkt`/`srid` 대신 `self.input_layer` (QgsVectorLayer)를 직접 clip mask로 전달.

```python
def __init__(self, input_layer, name_field, level,
             data_source='db', soil_path=None, lc_path=None):
    super().__init__()
    self.input_layer = input_layer
    self.name_field  = name_field
    self.level       = level
    self.data_source = data_source
    self.soil_path   = soil_path
    self.lc_path     = lc_path
```

`run()` 내부 분기:
```python
if self.data_source == 'local':
    # 소유역 전체 영역 Union (clip mask로 사용)
    dissolved = proc.run("native:dissolve", {...})['OUTPUT']

    # ① 로컬 토양군 Clip
    self.progress.emit(8, "① 로컬 토양군 Clip 중...")
    soil_clipped = load_local_soil(self.soil_path, dissolved)
    self.layer_ready.emit(soil_clipped, "토양군_clip")

    # ② 로컬 토지피복도 Clip + Dissolve
    self.progress.emit(26, "② 로컬 토지피복도 Clip 중...")
    lc_clipped = load_local_land_cover(self.lc_path, dissolved, self.level)
    self.layer_ready.emit(lc_clipped, "토지피복도_clip")

    # ③ 로컬 Intersection (토양군 × 토지피복도)
    self.progress.emit(44, "③ Intersection(토양군 × 토지피복도) 중...")
    soil_lc = get_local_soil_lc_intersection(soil_clipped, lc_clipped, self.level)
    self.layer_ready.emit(soil_lc, "토양군_토지피복_교차")

    # ④ Intersection × 소유역계 (DB 모드와 동일)
    self.progress.emit(72, "④ Intersection × 소유역계 중...")
    final_intersect = intersect_layers(soil_lc, self.input_layer, "최종교차_raw")
    self.finished.emit(final_intersect, [])
else:
    # 기존 DB 모드 로직 그대로 (변경 없음)
    ...
```

**스레드 안전 주의:** 로컬 모드 `processing.run()` 호출 3건 (clip, dissolve, intersection)은 DB 모드와 마찬가지로 CnWorker QThread 내에서 실행. 기존 DB 모드에서도 Step ④에서 `processing.run()`을 호출하고 있으므로 동일 패턴. QGIS Processing은 QThread에서 호출 가능하나, 메인 스레드 UI 접근은 시그널을 통해서만 수행 (기존 패턴 그대로).

---

### Task 3: Tab 0 UI에 데이터 소스 선택 위젯 추가
**Priority:** HIGH | **Complexity:** MEDIUM | **Depends on:** Task 2

Tab 0 (레이어 불러오기)에 데이터 소스 선택 라디오 버튼과 로컬 파일 경로 입력 위젯 추가.

**Acceptance Criteria:**
- 데이터 소스 라디오: `rbSourceDB` ("DB에서 가져오기", 기본 선택) / `rbSourceLocal` ("로컬 파일 사용")
- DB 선택 시: 기존 UI 그대로 (변경 없음)
- 로컬 선택 시: 토양군 파일 경로 (`leSoilPath` + `btnBrowseSoil`) + 토지피복도 파일 경로 (`leLcPath` + `btnBrowseLc`) 활성화
- 파일 선택 다이얼로그 필터: `"벡터 파일 (*.shp *.gpkg);;모든 파일 (*)"`
- 로컬 선택 시 파일 경로 필수 검증 (빈 경로 → 경고)
- `_run()` 메서드에서 `CnWorker` 생성 시 `data_source`/`soil_path`/`lc_path` 전달
- **`_run()`에서 `self.input_layer = input_layer` 저장** (Tab 3 유역합성 UI에서 소유역명 조회에 필요)

**Implementation Notes:**
- UI는 `.ui` 파일 수정 대신 `dialog.py`에서 동적 생성 (기존 `_setup_mapping_tab()` 패턴 따름)
- Tab 0의 기존 레이아웃에 위젯을 프로그래매틱으로 삽입
- `_toggle_data_source()` 메서드로 위젯 활성/비활성 전환
- 스타일: 기존 카드 패턴 (white bg, #e5e7eb border, 8px radius)

**UI 레이아웃 (로컬 모드 활성 시):**
```
┌─ 데이터 소스 ─────────────────────────────┐
│ ○ DB에서 가져오기  ● 로컬 파일 사용       │
│                                            │
│ 토양군 파일:  [________________________] [찾아보기] │
│ 토지피복도:   [________________________] [찾아보기] │
└────────────────────────────────────────────┘
```

---

### Task 4: core/watershed_group.py 신규 생성
**Priority:** HIGH | **Complexity:** LOW

유역합성 그룹 정의를 관리하는 모듈. `land_use_mapper.py` 패턴을 따름.

**Acceptance Criteria:**
- `load_groups(path=None)` → `dict[str, list[str]]` (그룹명 → 소유역명 리스트)
- `save_groups(groups, path=None)` → JSON 파일 저장
- 기본 저장 경로: `<plugin_root>/watershed_groups.json`
- 빈 그룹, 중복 소유역 허용 (사용자 책임)

**Implementation Notes:**
```python
# watershed_groups.json 예시
{
  "00천1": ["H1", "H2", "H3"],
  "00천2": ["H1", "H2"],
  "본류": ["H1", "H2", "H3", "H4", "H5"]
}
```

```python
GROUPS_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'watershed_groups.json')

def load_groups(path: str = None) -> dict:
    """저장된 유역합성 그룹 로드. 반환: {그룹명: [소유역1, 소유역2, ...]}"""

def save_groups(groups: dict, path: str = None):
    """유역합성 그룹을 JSON으로 저장."""
```

---

### Task 5: 유역합성 설정 카드를 Tab 3 내부에 삽입
**Priority:** HIGH | **Complexity:** MEDIUM | **Depends on:** Task 4

**확정 접근: Tab 3 (CN값 계산) 내부에 카드 삽입.** 새 탭 추가 없음 (Minor Issue #4 해결).

**Acceptance Criteria:**
- Tab 3 (CN값 계산)에 "유역합성 설정" 카드를 CN값 계산 실행 카드와 결과 내보내기 카드 사이에 삽입
- 그룹 관리 테이블: `QTableWidget` with 11 columns (그룹명 + 소유역1~10)
- 소유역 목록은 **Tab 0 입력 레이어의 `name_field` 고유값**에서 조회 (Critical Issue #4 해결)
  - `self._last_name_field`와 `self.input_layer`를 사용
  - `CN값_input` 레이어는 아직 존재하지 않을 수 있으므로 사용하지 않음
- 행 추가/삭제 버튼
- 저장/불러오기 버튼
- 저장 시 `watershed_groups.json`에 저장

**Implementation Notes:**
- `_setup_watershed_group_card()` 메서드로 동적 생성
- `_enhance_recalc_tab()` 내부에서 호출 (기존 패턴)
- VBA 매크로 "in" 시트 구조 참조: E=그룹명, F~O=유역1~유역10
- 소유역 목록 조회 소스 (우선순위):
  1. Tab 0에서 로드된 입력 레이어 (`self.input_layer`)의 `self._last_name_field` 고유값
  2. 입력 레이어 미로드 시 → 빈 콤보박스 (사용자 직접 입력)
- "레이어에서 불러오기" 버튼: 입력 레이어의 name_field 고유값을 콤보박스/자동완성으로 제공

**UI 레이아웃 (Tab 3 내부):**
```
Tab 3: CN값 계산
  ┌─ CN값 계산 실행 카드 ──┐  (기존, 동적 삽입)
  ├─ 유역합성 설정 카드 ───┤  (신규, 동적 삽입)
  │  [그룹 테이블 11열]     │
  │  [+ 행추가] [- 행삭제]  │
  │  [저장] [불러오기]      │
  ├─ 결과 내보내기 카드 ───┤  (기존)
  └─────────────────────────┘
```

---

### Task 6: result_calculator.py 헬퍼 추출 + 합성 CN 계산 로직 추가
**Priority:** HIGH | **Complexity:** MEDIUM | **Depends on:** Task 4

**확정 접근: Architect 권고 Q1 Option B — 헬퍼 함수 추출** (Critical Issue #3 해결).

**Acceptance Criteria:**
- `_calculate_watershed_cn(ws_name, ws_df)` 헬퍼 추출 (Lines 94-170 상당)
  - 반환: `(result1_entry, result2_entry)` — 기존 `calculate_results()` 내부 루프 본문
- `calculate_results()` 시그니처 **변경 없음** — 내부적으로 `_calculate_watershed_cn()` 호출
- `calculate_grouped_results(layer, groups)` 신규 함수 — 동일 헬퍼 호출
- 코드 중복 0줄 (AMC2/AMC3 로직은 헬퍼에만 존재)

**Implementation Notes:**

#### 헬퍼 추출 (`_amc3()` 패턴 따름)

```python
def _calculate_watershed_cn(ws_name: str, ws_df: pd.DataFrame) -> tuple:
    """
    단일 유역(또는 합성 유역)의 CN값 계산.
    ws_df: DataFrame with columns [소유역명, 토지이용, 유역면적, 토양군, cn값]
    반환: (result1_entry: dict, result2_entry: dict)

    기존 calculate_results() Lines 94-170의 로직을 그대로 추출.
    """
    # lu → {hydro: [total_area, cn_value]} 집계
    lu_map: dict[str, dict] = {}
    for _, row in ws_df.iterrows():
        lu  = row['토지이용']
        ht  = row['토양군']
        area = row['유역면적']
        cn   = row['cn값']
        if lu not in lu_map:
            lu_map[lu] = {h: [0.0, None] for h in HYDRO_TYPES}
        if ht in HYDRO_TYPES:
            lu_map[lu][ht][0] += area
            if cn is not None:
                lu_map[lu][ht][1] = cn

    all_lus = sorted(lu_map.keys())
    ws_rows = []
    ws_total_area = 0.0
    ws_total_by_type = {h: 0.0 for h in HYDRO_TYPES}
    ws_cn_area_sum = 0.0
    ws_amc3_area_sum = 0.0

    for lu in all_lus:
        ht_data = lu_map.get(lu, {h: [0.0, None] for h in HYDRO_TYPES})
        row_total = sum(ht_data[h][0] for h in HYDRO_TYPES)
        cn_area_sum = sum(
            ht_data[h][0] * ht_data[h][1]
            for h in HYDRO_TYPES
            if ht_data[h][1] is not None
        )
        amc2 = cn_area_sum / row_total if row_total > 0 else 0.0
        amc3 = _amc3(amc2, lu) if row_total > 0 else 0

        ws_total_area    += row_total
        ws_cn_area_sum   += cn_area_sum
        ws_amc3_area_sum += amc3 * row_total
        for h in HYDRO_TYPES:
            ws_total_by_type[h] += ht_data[h][0]

        def _area(h):
            v = ht_data[h][0]
            return v if v > 0 else None

        ws_rows.append({
            'land_use':   lu,
            'A_area': _area('A'), 'A_cn': ht_data['A'][1],
            'B_area': _area('B'), 'B_cn': ht_data['B'][1],
            'C_area': _area('C'), 'C_cn': ht_data['C'][1],
            'D_area': _area('D'), 'D_cn': ht_data['D'][1],
            'total_area': row_total if row_total > 0 else None,
            'amc2_cn':    amc2      if row_total > 0 else None,
            'amc3_cn':    amc3      if row_total > 0 else None,
        })

    ws_amc2 = ws_cn_area_sum   / ws_total_area if ws_total_area > 0 else 0.0
    ws_amc3 = ws_amc3_area_sum / ws_total_area if ws_total_area > 0 else 0.0

    result1_entry = {
        'watershed': ws_name, 'rows': ws_rows,
        'total_area': ws_total_area,
        'total_A': ws_total_by_type['A'], 'total_B': ws_total_by_type['B'],
        'total_C': ws_total_by_type['C'], 'total_D': ws_total_by_type['D'],
        'amc2_cn': ws_amc2, 'amc3_cn': ws_amc3,
    }
    result2_entry = {
        'watershed': ws_name, 'total_area': ws_total_area,
        'amc2_cn': ws_amc2, 'amc3_cn': ws_amc3,
    }
    return result1_entry, result2_entry
```

#### calculate_results() 리팩토링

```python
def calculate_results(layer: QgsVectorLayer):
    """시그니처 변경 없음. 내부적으로 _calculate_watershed_cn() 호출."""
    df = layer_to_dataframe(layer)
    if df.empty:
        raise ValueError("레이어에 데이터가 없습니다.")

    null_mask = df['cn값'].isna() & (df['유역면적'] > 0)
    null_cn_rows = df[null_mask][['소유역명', '토지이용', '토양군']].values.tolist()

    watersheds = list(dict.fromkeys(df['소유역명'].dropna().tolist()))
    result1_data = []
    result2_data = []

    for ws_name in watersheds:
        ws_df = df[df['소유역명'] == ws_name]
        r1_entry, r2_entry = _calculate_watershed_cn(ws_name, ws_df)
        result1_data.append(r1_entry)
        result2_data.append(r2_entry)

    logger.info(f"계산 완료: {len(watersheds)}개 소유역")
    return result1_data, result2_data, null_cn_rows
```

#### calculate_grouped_results() 신규 함수

```python
def calculate_grouped_results(layer: QgsVectorLayer,
                              groups: dict) -> tuple:
    """
    유역합성 그룹별 CN값 계산.
    groups: {그룹명: [소유역1, 소유역2, ...]}
    반환: (grouped_result1_data, grouped_result2_data)

    핵심: 멤버 소유역들의 원시 데이터를 합산하여 하나의 가상 유역으로 처리.
    _calculate_watershed_cn() 헬퍼를 재활용 → 코드 중복 없음.
    """
    df = layer_to_dataframe(layer)
    grouped_result1 = []
    grouped_result2 = []

    for group_name, members in groups.items():
        # 멤버 소유역의 모든 행을 합쳐서 하나의 가상 유역 DataFrame 생성
        group_df = df[df['소유역명'].isin(members)]
        if group_df.empty:
            logger.warning(f"유역합성 '{group_name}': 멤버 소유역 데이터 없음 ({members})")
            continue
        r1_entry, r2_entry = _calculate_watershed_cn(group_name, group_df)
        grouped_result1.append(r1_entry)
        grouped_result2.append(r2_entry)

    logger.info(f"유역합성 계산 완료: {len(grouped_result1)}개 그룹")
    return grouped_result1, grouped_result2
```

---

### Task 7: results.xlsx 출력에 합성 결과 포함
**Priority:** HIGH | **Complexity:** MEDIUM | **Depends on:** Task 6

`export_results()` 시그니처 확장으로 합성 결과를 results.xlsx에 추가.

**Acceptance Criteria:**
- `result1` 시트: 개별 소유역 블록 → 빈 행 → "【유역합성】" 구분 헤더 → 합성 유역 블록
- `result2` 시트: 개별 소유역 행 → 빈 행 → "【유역합성】" 구분 헤더 → 합성 유역 행
- 합성 유역 블록/행은 시각적으로 구분 (연두색 fill: `#CCFFCC`)
- 유역합성이 없는 경우 (`grouped_result1=None`): 기존과 동일한 출력 (하위 호환)

**Implementation Notes:**

#### export_results() 시그니처 확장 (Minor Issue #1 해결)

```python
def export_results(result1_data: list, result2_data: list, path: str,
                   *, grouped_result1: list = None, grouped_result2: list = None):
    """
    results.xlsx: result1 시트 + result2 시트를 하나의 파일에 저장.
    grouped_result1/grouped_result2가 제공되면 합성 결과도 추가.

    신규 파라미터는 keyword-only + None 기본값 → 기존 호출 코드 변경 불필요.
    """
```

- `*` 구분자로 keyword-only 강제 → 위치 인자로 전달 불가
- `None` 기본값 → 기존 `export_results(r1, r2, path)` 호출 그대로 동작
- 합성 결과 블록 fill: `fill_green = PatternFill(patternType='solid', fgColor='FFCCFFCC')` (연두색)
- result1 시트: 개별 블록 출력 완료 후, 합성 블록 전에 "【유역합성】" 헤더행 삽입
- result2 시트: 개별 행 출력 완료 후, 합성 행 전에 빈 행 + "【유역합성】" 헤더행 삽입

---

### Task 8: dialog.py 통합 및 워크플로우 연결 + 테스트 시나리오
**Priority:** HIGH | **Complexity:** MEDIUM | **Depends on:** Task 3, 5, 7

모든 기능을 dialog.py에 통합하여 전체 워크플로우가 동작하도록 연결.

**Acceptance Criteria:**
- Tab 0: 데이터 소스 전환 → CnWorker에 올바른 파라미터 전달
- Tab 3: 유역합성 그룹 정의 UI → `_export_results()`에서 합성 결과 포함
- `_export_results()` 수정: `calculate_grouped_results()` 호출 + `export_results()` 확장 호출
- 유역합성 그룹이 비어있으면 기존과 동일하게 동작

**Implementation Notes:**

`_export_results()` 수정 흐름:
```python
def _export_results(self):
    layer = self._get_recalc_layer()
    folder = self._get_output_dir()
    path = os.path.join(folder, "results.xlsx")

    # 개별 소유역 결과
    result1_data, result2_data, null_cn_rows = calculate_results(layer)

    # 유역합성 결과 (그룹이 있는 경우)
    groups = self._get_watershed_groups()  # Tab 3 테이블에서 읽기
    grouped_r1, grouped_r2 = None, None
    if groups:
        grouped_r1, grouped_r2 = calculate_grouped_results(layer, groups)

    export_results(result1_data, result2_data, path,
                   grouped_result1=grouped_r1, grouped_result2=grouped_r2)
```

Import 추가:
```python
from .core.result_calculator import calculate_results, calculate_grouped_results, export_results
from .core.watershed_group import load_groups, save_groups
```

**테스트 시나리오 (Minor Issue #2 해결):**

| # | 시나리오 | 입력 | 기대 결과 |
|---|---------|------|----------|
| 1 | DB 모드 정상 동작 | 기존 소유역 SHP + DB 연결 | 기존과 동일한 CN값_input + results.xlsx |
| 2 | 로컬 모드 - canonical 컬럼명 | SHP with hydro_type, l1_name | 정상 처리, 리네이밍 없이 통과 |
| 3 | 로컬 모드 - 한국어 컬럼명 | SHP with 수문학토양군, 대분류명 | 자동 감지 → 리네이밍 → 정상 처리 |
| 4 | 로컬 모드 - 컬럼 누락 | SHP with 잘못된 컬럼명 | ValidationError + 한국어 에러 메시지 |
| 5 | 유역합성 - 그룹 정의 + 계산 | 3개 소유역을 2개 그룹으로 | results.xlsx에 개별 3건 + 합성 2건 |
| 6 | 유역합성 - 빈 그룹 | 그룹 정의 없음 | 기존과 동일 출력 (합성 섹션 없음) |
| 7 | 유역합성 - 멤버 소유역 없음 | 그룹 멤버가 레이어에 없는 이름 | 해당 그룹 스킵 + 경고 로그 |
| 8 | 로컬 + 유역합성 조합 | 로컬 SHP + 유역합성 그룹 | 양쪽 기능 모두 정상 동작 |

---

## Commit Strategy

### Commit 1: Feature 1 - 로컬 데이터 입력
- `core/local_data_handler.py` (신규 — 컬럼 자동 감지 + canonical 리네이밍 포함)
- `dialog.py` (CnWorker 분기 + Tab 0 UI 확장)
- Message: `feat: 토양군/토지피복도 로컬 파일 입력 기능 추가 (한국어 컬럼 자동 감지)`

### Commit 2: Feature 2 - 유역합성
- `core/watershed_group.py` (신규)
- `core/result_calculator.py` (헬퍼 추출 + 합성 계산 로직 추가)
- `dialog.py` (유역합성 카드 UI + export 연결)
- Message: `feat: 유역합성(Watershed Grouping) CN값 계산 기능 추가`

### Commit 3: Documentation
- `CLAUDE.md` 업데이트 (새 모듈/기능 문서화)
- Message: `docs: 로컬 데이터 입력 및 유역합성 기능 문서 추가`

---

## Success Criteria

1. **기존 워크플로우 무결성**: DB 모드로 기존과 동일하게 CN값_input 생성 + results.xlsx 출력 가능
2. **로컬 모드 동작**: 로컬 SHP/GPKG 토양군+토지피복도로 전체 파이프라인 완료 (한국어 컬럼명 자동 감지)
3. **유역합성 동작**: 그룹 정의 → 저장 → CN값 계산 시 합성 결과가 results.xlsx에 포함
4. **헬퍼 중복 제거**: AMC2/AMC3 계산 로직이 `_calculate_watershed_cn()`에만 존재 (단일 소스)
5. **에러 처리**: 잘못된 파일/컬럼 구조 시 사용자 친화적 한국어 에러 메시지 표시
6. **UI 일관성**: 기존 디자인 스타일 가이드 (카드 패턴, 색상 토큰, 폰트) 준수

---

## File Change Summary

| File | Action | Description |
|------|--------|-------------|
| `core/local_data_handler.py` | NEW | 로컬 파일 로드/Clip/Intersection + 컬럼 자동 감지/리네이밍 |
| `core/watershed_group.py` | NEW | 유역합성 그룹 JSON 관리 |
| `dialog.py` | MODIFY | CnWorker 분기, Tab 0 UI 확장, 유역합성 카드 (Tab 3 내부), export 연결 |
| `core/result_calculator.py` | MODIFY | `_calculate_watershed_cn()` 헬퍼 추출, `calculate_grouped_results()` 추가, `export_results()` keyword-only 파라미터 확장 |
| `CLAUDE.md` | MODIFY | 신규 모듈/기능 문서화 |

**기존 파일 변경 없음:**
- `core/db_manager.py` - 변경 불필요
- `core/spatial_ops.py` - 기존 함수 재활용 (수정 불필요)
- `core/cn_matcher.py` - 변경 불필요
- `core/land_use_mapper.py` - 변경 불필요
- `plugin.py` - 변경 불필요
- `reference/cn_calculator.ui` - 변경 불필요 (동적 UI 생성)

---

## Critical Issue Resolution Summary

| Issue | Resolution |
|-------|-----------|
| #1 로컬 파일 컬럼명 | `SOIL_COLUMN_ALIASES` / `LC_COLUMN_ALIASES` + `_resolve_columns()` 자동 감지 → `_rename_columns()` canonical 리네이밍. `local_data_handler` 내부에서만 수행 |
| #2 함수 시그니처 모순 | 단일 시그니처: `load_local_soil(file_path, clip_layer)`. clip 파라미터는 QgsVectorLayer. WKT 사용 안 함 |
| #3 코드 중복 | `_calculate_watershed_cn(ws_name, ws_df)` 헬퍼 추출. `calculate_results()`와 `calculate_grouped_results()` 모두 이 헬퍼 호출 |
| #4 소유역 목록 소스 | Tab 0 입력 레이어의 `name_field` 고유값 사용 (`self.input_layer` + `self._last_name_field`). `CN값_input` 사용 안 함 |
| Minor #1 | `export_results()` 신규 파라미터 keyword-only (`*` 구분자) + `None` 기본값 |
| Minor #2 | Task 8에 8개 테스트 시나리오 테이블 추가 |
| Minor #3 | Task 2에 스레드 안전 주의사항 명시 (기존 Step ④와 동일 패턴) |
| Minor #4 | Tab 3 내부 카드 삽입으로 확정 (새 탭 추가 없음) |
| v2 Critical #1 | `_run()`에서 `self.input_layer = input_layer` 저장 추가 (Task 3) — Tab 3 유역합성 UI 소유역명 조회용 |
| v2 Minor #1 | `_rename_columns()` 구현 순서 pseudocode 추가 |
| v2 Minor #2 | 모든 canonical == actual이면 원본 반환 (복사 없음) 최적화 명시 |
