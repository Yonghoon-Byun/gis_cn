<!-- Generated: 2026-03-10 | Updated: 2026-03-10 -->

# GIS CN값 계산기 (QGIS Plugin)

## Purpose
QGIS 플러그인으로, 유역(watershed) 경계를 기반으로 PostGIS에서 토양군/토지피복도를 공간교차(ST_Intersection)한 뒤 CN(Curve Number)값을 산출하고 AMC2/AMC3 결과를 Excel로 내보내는 수문분석 도구입니다.

## Key Files
| File | Description |
|------|-------------|
| `__init__.py` | QGIS 플러그인 팩토리 (classFactory) |
| `plugin.py` | 툴바/메뉴 등록 및 다이얼로그 실행 |
| `dialog.py` | 메인 UI 컨트롤러 (4개 탭, QThread 백그라운드 처리) |
| `metadata.txt` | QGIS Plugin Manager용 메타데이터 |
| `CLAUDE.md` | 아키텍처 문서 |
| `cn.png` | 플러그인 아이콘 |
| `cn_value.xlsx` | 기본 CN값 조회 테이블 (토지이용×토양군) |
| `cn_cal.xlsm` | Excel 참고 파일 |
| `dims_dump.json` | UI 치수 메타데이터 |
| `strings_dump.json` | UI 문자열 매핑 |

## Subdirectories
| Directory | Purpose |
|-----------|---------|
| `core/` | 비즈니스 로직 모듈 (see `core/AGENTS.md`) |
| `reference/` | UI 디자인 참고 파일 (see `reference/AGENTS.md`) |

## For AI Agents

### Working In This Directory
- QGIS 3.x + PyQt5 환경 기반 플러그인
- PostGIS(Azure) 연결 필수: psycopg2 사용
- pandas, openpyxl 의존성
- EPSG:5186 (Korea TM) 좌표계 사용
- dialog.py가 핵심 오케스트레이터 (1132줄) — 수정 시 주의

### Architecture & Workflow
1. **Tab 0 (레이어 불러오기):** SHP/GPKG 선택 → CnWorker(QThread)로 PostGIS 공간교차 실행
2. **Tab 1 (토지이용 재분류):** 토지피복 명칭 → 토지이용 분류 매핑
3. **Tab 2 (CN값 편집):** CN 조회 테이블 편집/가져오기
4. **Tab 3 (CN값 계산):** CN 매칭 → AMC2/AMC3 계산 → results.xlsx 내보내기

### Key Data Flow
```
유역 SHP → PostGIS ST_Intersection(토양군, 토지피복도) → QGIS Intersection → CN값_input 레이어
→ 토지이용 재분류 → CN값 매칭 → AMC2/AMC3 계산 → Excel 내보내기
```

### Testing Requirements
- QGIS Python 콘솔에서 테스트
- PostGIS 연결 필요 (geo-spatial-hub.postgres.database.azure.com)
- 테스트 SHP: 유역 경계 폴리곤 (EPSG:5186)

### Common Patterns
- `_is_null()`: Python None, QVariant NULL, float NaN 통합 처리
- `_get_field_value()`: native:intersection 컬럼명 접미사 문제 해결
- QThread signals: `progress`, `layer_ready`, `finished`, `error`
- CN 테이블 우선순위: Tab 2 위젯 > 임포트 xlsx > 기본 cn_value.xlsx

## Dependencies

### External
- QGIS 3.x (Processing framework, PyQt5)
- psycopg2 (PostGIS 연결)
- pandas (DataFrame 연산)
- openpyxl (Excel 내보내기)

<!-- MANUAL: -->
