<!-- Parent: ../AGENTS.md -->
<!-- Generated: 2026-03-10 | Updated: 2026-03-10 -->

# ui - 참고용 UI 컴포넌트

## Purpose
플러그인 UI 모듈화를 위한 참고 구현체. 현재 런타임에서 직접 사용되지 않으며, 향후 UI 리팩토링 시 패턴 참고용.

## Key Files
| File | Description |
|------|-------------|
| `__init__.py` | UI 모듈 초기화 |
| `main_dialog.py` | 메인 다이얼로그 참고 구현 (23KB) |
| `region_tab.py` | 지역 선택 탭 참고 구현 (11KB) |
| `statistics_tab.py` | 통계 패널 참고 구현 (15KB) |
| `styling_tab.py` | 스타일링 패널 참고 구현 (13KB) |

## For AI Agents

### Working In This Directory
- 모든 파일이 참고용 (reference) — 런타임 미사용
- dialog.py 리팩토링 시 이 패턴을 참고하여 탭별 모듈 분리 가능
- Tailwind-like 색상 토큰과 Pretendard 폰트 스타일 가이드 포함

### Common Patterns
- 탭별 클래스 분리 (RegionTab, StatisticsTab, StylingTab)
- QSS 기반 글로벌 스타일시트
- Signal/Slot 기반 이벤트 처리

## Dependencies

### Internal
- 참고용이므로 직접 의존성 없음

### External
- PyQt5 (QDialog, QTableWidget, etc.)

<!-- MANUAL: -->
