# UI 변경 프롬프트 가이드

`reference/ui/` 파일들의 UI를 `region_selector_dialog.py`와 동일한 디자인 감성으로 변경할 때 사용하는 참조 문서입니다.

**핵심 원칙:** 탭 구조·레이아웃 로직·시그널·비즈니스 로직은 그대로 유지하고, 폴트·색상·간격 등 스타일만 통일합니다.

---

## 1. 글로벌 스타일시트

`main_dialog.py`의 `DIALOG_STYLESHEET`를 아래로 교체합니다. 각 탭 파일의 개별 스타일은 이 글로벌 스타일시트와 충돌하지 않도록 반드시 `border: none;`을 명시합니다.

```python
DIALOG_STYLESHEET = """
* {
    font-family: 'Pretendard', 'Pretendard Variable', 'Malgun Gothic', 'Apple SD Gothic Neo', sans-serif;
    font-weight: 500;
}
QDialog {
    background-color: #f9fafb;
}
QLabel {
    color: #374151;
    font-weight: 500;
}
QComboBox {
    border: 1px solid #d1d5db;
    border-radius: 4px;
    padding: 8px 12px;
    background-color: #f9fafb;
    font-size: 14px;
    color: #374151;
}
QComboBox:hover {
    border-color: #9ca3af;
    background-color: white;
}
QComboBox::drop-down {
    border: none;
    width: 24px;
}
QComboBox QAbstractItemView {
    border: 1px solid #d1d5db;
    background-color: white;
    selection-background-color: #e5e7eb;
}
QSpinBox, QDoubleSpinBox {
    border: 1px solid #d1d5db;
    border-radius: 4px;
    padding: 8px 12px;
    background-color: #f9fafb;
    font-size: 14px;
    color: #374151;
}
QSpinBox:hover, QDoubleSpinBox:hover {
    border-color: #9ca3af;
}
QLineEdit {
    border: 1px solid #d1d5db;
    border-radius: 4px;
    padding: 8px 12px;
    background-color: #f9fafb;
    font-size: 14px;
    color: #374151;
}
QLineEdit:hover {
    border-color: #9ca3af;
}
QLineEdit:focus {
    border-color: #6b7280;
    background-color: white;
}
QScrollArea {
    border: none;
    background-color: transparent;
}
QScrollBar:vertical {
    background-color: #f3f4f6;
    width: 10px;
    border-radius: 5px;
    margin: 2px;
}
QScrollBar::handle:vertical {
    background-color: #9ca3af;
    border-radius: 4px;
    min-height: 30px;
}
QScrollBar::handle:vertical:hover {
    background-color: #6b7280;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0px;
}
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {
    background: none;
}
QScrollBar:horizontal {
    background-color: #f3f4f6;
    height: 10px;
    border-radius: 5px;
    margin: 2px;
}
QScrollBar::handle:horizontal {
    background-color: #9ca3af;
    border-radius: 4px;
    min-width: 30px;
}
QScrollBar::handle:horizontal:hover {
    background-color: #6b7280;
}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {
    width: 0px;
}
QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {
    background: none;
}
"""
```

> 탭 파일 내 `_get_combo_style()`, `_get_spinbox_style()`, `_get_lineedit_style()` 등 개별 스타일 메서드는 글로벌 스타일시트와 중복되므로 제거하고, 해당 위젯에 개별 setStyleSheet를 하지 않아도 됩니다.

---

## 2. 폰트 사이즈 변환 테이블

현재 파일의 폰트 사이즈를 아래 기준으로 변환합니다.

| 요소 유형 | 기존 크기 | 변경 후 크기 |
|-----------|-----------|--------------|
| 다이얼로그 제목 (header title) | 16px | **18px** |
| 카드 헤더 (card header) | 13px | **15px** |
| 설명문 (description) | 11px | **13px** |
| 라벨 (시도·시군구·읽면동 등) | 12px | **14px** |
| 콤보박스·스핀박스·라인에딧 | 12px | **14px** (글로벌로 처리) |
| QgsMapLayerComboBox | 11px | **14px** |
| 액션 버튼 (다음 단계·분석 실행) | 12px | **14px** |
| 세컨더리 버튼 (이전·닫기) | 12px | **14px** |
| 스테퍼 버튼 | 11px | **13px** |
| 칩 버튼 (소유주체) | 11px | **13px** |
| 전체선택·전체해제 버튼 | 11px | **13px** |
| 배지 (N개 선택 등) | 10px | **11px** |
| 값 배지 (고도·경사 등) | 11px | **12px** |
| 요약바 라벨 | 10px | **12px** |
| 프로그레스 상태 라벨 | 11px | **13px** |
| 안내 박스 제목 | 11px | **13px** |
| 안내 박스 본문 | 10px~11px | **12px** |
| 안내 박스 아이콘 (i, ℹ, ✓) | 12px~14px | **유지** (크기 적절) |
| 슬라이더 범위 라벨 (0m·100m) | 10px | **11px** |
| 출력 레이어명 라벨 | 12px | **14px** |

---

## 3. 색상 토큰

기존 파일과 이미 동일한 색상 토큰을 사용하고 있으므로 **색상은 변경하지 않습니다.** 참조용으로 정리합니다.

| 용도 | 색상 |
|------|------|
| 기본 텍스트 | `#374151` |
| 세컨더리 텍스트 | `#6b7280` |
| 비활성 텍스트 | `#9ca3af` |
| 타이틀 강조 | `#1f2937` |
| 카드 배경 | `white` |
| 카드 테두리 | `#e5e7eb` |
| 다이얼로그 배경 | `#f9fafb` |
| 입력 필드 배경 | `#f9fafb` |
| 입력 테두리 | `#d1d5db` |
| 입력 테두리 hover | `#9ca3af` |
| 액션 버튼 배경 | `#1f2937` |
| 액션 버튼 hover | `#374151` |
| 안내 박스 (파란색) | bg `#dbeafe`, border `#93c5fd`, text `#1e40af` |
| 안내 박스 (회색) | bg `#f3f4f6`, border `#e5e7eb`, text `#374151` |
| 안내 박스 (녹색/완료) | bg `#f0fdf4`, border `#86efac`, text `#166534` |
| 안내 박스 (연파란색) | bg `#eff6ff`, border `#bfdbfe`, text `#1e40af` |
| 프로그레스 프레임 | bg `#fef3c7`, border `#fcd34d` |
| 프로그레스 상태 텍스트 | `#92400e` |
| 프로그레스 바 | bg `#fde68a`, chunk `#f59e0b` |
| 값 배지 (녹색) | bg `#dcfce7`, text `#166534` |
| 값 배지 (주황) | bg `#fef3c7`, text `#92400e` |
| 선택 완료 표시 | `#059669` |
| 링크색 버튼 | `#3b82f6` |

---

## 4. 파일별 변경 세부 지침

### main_dialog.py

- `DIALOG_STYLESHEET` → 위의 글로벌 스타일시트로 교체
- `_create_header()` : title font-size `16px` → `18px`
- `_create_stepper()` : `StepperButton` active/inactive 폰트 `11px` → `13px`
- `_create_summary_bar()` : 각 라벨 font-size `10px` → `12px`
- `_create_progress_frame()` : status 라벨 `11px` → `13px`
- `_create_footer()` : 이전 버튼 `12px` → `14px`, 액션 버튼 `12px` → `14px`, 닫기 버튼 `12px` → `14px`
- 구조·시그널·로직: **변경 없음**

### region_tab.py

- `_create_region_card()` : header `13px` → `15px`, desc `11px` → `13px`, 시도·시군구·읽면동 라벨 `12px` → `14px`
- `_create_notice()` : icon `12px` → `13px`, text `11px` → `13px`
- `_get_combo_style()` : 글로벌 스타일시트로 커버되므로 **제거 가능**. 개별 setStyleSheet 호출도 제거
- 구조·시그널: **변경 없음**

### terrain_tab.py

- `_create_dem_selector_card()` : header `13px` → `15px`, desc `11px` → `13px`, QgsMapLayerComboBox `11px` → `14px`
- `_create_elevation_card()` : header `13px` → `15px`, badge `11px` → `12px`, desc `11px` → `13px`, 범위 라벨 `10px` → `11px`
- `_create_slope_card()` : 동일하게 위와 같은 규칙 적용
- `_create_notice()` : title `11px` → `13px`, items `10px` → `12px`
- `_get_spinbox_style()` : 글로벌로 커버됨 → **제거 가능**
- `_get_slider_style()` : 스타일 자체는 유지 (색상·핸들 크기 동일)
- 구조·시그널: **변경 없음**

### owner_tab.py

- `OwnerChipButton._update_style()` : selected/unselected 모두 `11px` → `13px`
- `_create_boundary_selector_card()` : header `13px` → `15px`, desc `11px` → `13px`, QgsMapLayerComboBox `11px` → `14px`
- `_create_owner_card()` : header `13px` → `15px`, badge `10px` → `11px`, 전체선택·전체해제 `11px` → `13px`, desc `11px` → `13px`
- `_update_badge()` : badge font-size `10px` → `11px` (두 곳 모두)
- `_create_info_card()` : header `13px` → `15px`, desc `11px` → `13px`
- 구조·시그널: **변경 없음**

### output_tab.py

- `_create_summary_card()` : header `13px` → `15px`
- `_create_summary_row()` : label·value `11px` → `13px`
- `_create_layer_selector_row()` : label `11px` → `13px`, QgsMapLayerComboBox `11px` → `14px`
- `_create_output_card()` : header `13px` → `15px`, 레이어명 라벨 `12px` → `14px`
- `_create_ready_card()` : header `13px` → `15px`, desc `11px` → `13px`, steps `10px` → `11px`
- `_get_lineedit_style()` : 글로벌로 커버됨 → **제거 가능**
- 구조·시그널: **변경 없음**

---

## 5. 변경하지 않는 것

다음 사항은 반드시 그대로 유지합니다.

- **탭 구조** : 4단계 스테퍼 (지역 선택 → 지형 조건 → 소유주체 → 출력 설정)
- **QStackedWidget** 기반 탭 전환 로직
- **모든 pyqtSignal** 및 시그널 연결 (region_changed, terrain_changed, owner_changed, settings_changed 등)
- **데이터 흐름** : set_region_data(), set_owner_list(), get_analysis_params() 등 모든 public 메서드와 반환값
- **안내 박스의 배경색 종류** : 파란색(정보), 회색(권장), 녹색(완료), 연파란색(안내) — 각각 의미가 있으므로 유지
- **슬라이더·스핀박스 동기화 로직** (blockSignals 패턴)
- **칩 버튼의 토글 상태 관리** (OwnerChipButton)
- **StepperButton 활성·비활성 상태 표시**

---

## 6. 프롬프트 템플릿

실제 변경 요청 시 다음과 같이 프롬프트를 작성합니다.

```
reference/ui/ 폴더 안의 파일들의 UI 스타일을 region_selector_dialog.py와 동일하게 통일해주세요.

변경 규칙:
1. main_dialog.py의 DIALOG_STYLESHEET를 prompt.md의 "1. 글로벌 스타일시트" 내용으로 교체
2. 폰트 사이즈는 prompt.md의 "2. 폰트 사이즈 변환 테이블" 기준으로 변환
3. 색상은 변경하지 않음
4. 탭 구조, 시그널, 비즈니스 로직은 변경하지 않음
5. 글로벌 스타일시트로 커버되는 개별 스타일 메서드(_get_combo_style, _get_spinbox_style, _get_lineedit_style)는 제거
6. 각 파일별 세부 변경사항은 prompt.md의 "4. 파일별 변경 세부 지침" 참조
```
