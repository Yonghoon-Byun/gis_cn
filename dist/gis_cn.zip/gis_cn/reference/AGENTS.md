<!-- Parent: ../AGENTS.md -->
<!-- Generated: 2026-03-10 | Updated: 2026-03-10 -->

# reference - UI 디자인 참고 자료

## Purpose
플러그인 UI 개발 시 참고용으로 보관하는 디자인 파일과 레퍼런스 구현체. 실제 런타임에서 사용되지 않음 (cn_calculator.ui 제외).

## Key Files
| File | Description |
|------|-------------|
| `cn_calculator.ui` | Qt Designer XML (Tab 0, 2, 3 UI 정의) — **실제 사용됨** |
| `prompt.md` | UI 스타일링 가이드 (폰트, 색상, 간격 표준) |
| `region_selector_dialog.py` | 지역 선택 다이얼로그 참고 구현 (미사용) |

## Subdirectories
| Directory | Purpose |
|-----------|---------|
| `ui/` | 참고용 UI 컴포넌트 구현체 (see `ui/AGENTS.md`) |

## For AI Agents

### Working In This Directory
- **cn_calculator.ui**는 dialog.py에서 실제 로드하므로 수정 시 주의
- 나머지 파일은 참고용이므로 자유롭게 수정 가능
- UI 스타일은 prompt.md의 Pretendard/Malgun Gothic, Tailwind 색상 체계 따름

### Testing Requirements
- cn_calculator.ui 수정 시 QGIS에서 플러그인 재로드하여 확인

## Dependencies

### Internal
- `cn_calculator.ui` ← `../dialog.py`에서 `uic.loadUiType()`으로 로드

<!-- MANUAL: -->
