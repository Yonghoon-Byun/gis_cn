import os
import logging

import pandas as pd
from qgis.PyQt import uic
from qgis.PyQt.QtWidgets import (
    QDialog, QFileDialog, QMessageBox,
    QInputDialog, QTableWidgetItem, QHeaderView,
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
    QLabel, QTableWidget, QAbstractItemView, QFrame,
    QStyledItemDelegate, QRadioButton, QLineEdit,
    QComboBox, QProgressBar, QScrollArea, QSizePolicy,
    QCheckBox,
)
from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal, QEvent
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsWkbTypes, QgsMapLayerType
)

from .core.db_manager import get_soil_layer, get_land_cover_layer, get_soil_lc_intersection, get_all_layers
from .core.local_data_handler import (
    load_local_soil, load_local_land_cover,
    get_local_soil_lc_intersection, ValidationError
)
from .core.spatial_ops import (
    intersect_layers,
    _build_result_layer, LEVEL_COLUMNS
)
from .core.cn_matcher import load_cn_table, apply_cn_to_layer, XLSX_PATH
from .core.result_calculator import (
    calculate_results, calculate_grouped_results, export_results,
    build_analysis_result, assemble_staged_report, export_excel, export_excel_staged,
)
from .core.analysis_result import (
    ProjectMeta, STAGE_PRE, STAGE_DURING, STAGE_POST, DEFAULT_STAGE_ORDER,
)
from .core.watershed_group import load_groups, save_groups

PLUGIN_DIR = os.path.dirname(__file__)
DEFAULT_HWP_TEMPLATE = os.path.join(PLUGIN_DIR, 'templates', 'v1.0', 'cn_report.hwpx')

logger = logging.getLogger(__name__)

FORM_CLASS, _ = uic.loadUiType(
    os.path.join(os.path.dirname(__file__), 'reference', 'cn_calculator.ui')
)

TAB_CALC    = 0   # 레이어 불러오기
TAB_CN_EDIT = 1   # CN값 편집 (.ui 원본 위치 유지)
TAB_MAPPING = 2   # 토지이용 재분류 (insertTab(2,...)로 삽입)
TAB_RECALC  = 3   # CN값 계산
TAB_REPORT  = 4   # 보고서 출력 (addTab 으로 추가)

# ── 카드 기반 다이얼로그 스타일 (reference/region_selector_dialog.py 기준) ──
DIALOG_STYLESHEET = """
* {
    font-family: 'Pretendard', 'Pretendard Variable', 'Malgun Gothic', 'Apple SD Gothic Neo', sans-serif;
    font-weight: 500;
    font-size: 13px;
}

/* ── 다이얼로그 ── */
QDialog { background-color: #f9fafb; }

/* ── 레이블 ── */
QLabel { color: #374151; font-weight: 500; }

/* ── 탭 위젯 ── */
QTabWidget::pane {
    border: none;
    background-color: #f9fafb;
}
QTabWidget > QWidget { background-color: #f9fafb; }
QTabBar {
    background-color: white;
    border-bottom: 1px solid #e5e7eb;
}
QTabBar::tab {
    background-color: transparent;
    color: #9ca3af;
    padding: 10px 22px;
    border: none;
    border-bottom: 2px solid transparent;
    font-size: 13px;
    font-weight: 500;
}
QTabBar::tab:selected {
    color: #1f2937;
    border-bottom: 2px solid #1f2937;
    font-weight: bold;
}
QTabBar::tab:hover:!selected { color: #6b7280; }

/* ── 입력 위젯 ── */
QComboBox {
    border: 1px solid #d1d5db;
    border-radius: 4px;
    padding: 6px 10px;
    background-color: #f9fafb;
    color: #374151;
}
QComboBox:hover { border-color: #9ca3af; background-color: white; }
QComboBox::drop-down { border: none; width: 20px; }
QComboBox QAbstractItemView {
    border: 1px solid #d1d5db;
    background-color: white;
    selection-background-color: #e5e7eb;
}

QLineEdit {
    border: 1px solid #d1d5db;
    border-radius: 4px;
    padding: 6px 10px;
    background-color: #f9fafb;
    color: #374151;
}
QLineEdit:hover  { border-color: #9ca3af; }
QLineEdit:focus  { border-color: #6b7280; background-color: white; }

/* ── 버튼 (기본: 아웃라인) ── */
QPushButton {
    border: 1px solid #d1d5db;
    border-radius: 6px;
    padding: 6px 14px;
    color: #374151;
    background-color: white;
    font-size: 13px;
}
QPushButton:hover {
    background-color: #f3f4f6;
    border-color: #9ca3af;
}
QPushButton:pressed { background-color: #e5e7eb; }
QPushButton:disabled {
    background-color: #f3f4f6;
    color: #9ca3af;
    border-color: #e5e7eb;
}

/* ── 주요 액션 버튼 (어두운 배경) ── */
QPushButton#btnRun,
QPushButton#btnSaveCn,
QPushButton#btnExportResult1 {
    background-color: #1f2937;
    color: white;
    border: none;
    font-weight: 600;
}
QPushButton#btnRun:hover,
QPushButton#btnSaveCn:hover,
QPushButton#btnExportResult1:hover {
    background-color: #374151;
}
QPushButton#btnRun:disabled { background-color: #9ca3af; }

/* ── 진행바 ── */
QProgressBar {
    background-color: #e5e7eb;
    border: none;
    border-radius: 3px;
    text-align: center;
    font-size: 10px;
    color: #6b7280;
}
QProgressBar::chunk {
    background-color: #1f2937;
    border-radius: 3px;
}

/* ── 텍스트 에디터 (로그) ── */
QTextEdit {
    border: 1px solid #e5e7eb;
    border-radius: 6px;
    background-color: white;
    padding: 6px;
    color: #374151;
}

/* ── 테이블 ── */
QTableWidget {
    border: 1px solid #e5e7eb;
    border-radius: 6px;
    background-color: white;
    gridline-color: #f3f4f6;
    selection-background-color: #f3f4f6;
    selection-color: #1f2937;
}
QTableWidget::item { padding: 3px 6px; color: #374151; }
QTableWidget::item:selected {
    background-color: #f3f4f6;
    color: #1f2937;
}
QHeaderView::section {
    background-color: #f9fafb;
    border: none;
    border-bottom: 1px solid #e5e7eb;
    border-right: 1px solid #e5e7eb;
    padding: 5px 8px;
    font-size: 12px;
    font-weight: 600;
    color: #6b7280;
}

/* ── 라디오/체크 버튼 ── */
QRadioButton, QCheckBox {
    color: #374151;
    spacing: 7px;
}
QRadioButton::indicator {
    width: 15px;
    height: 15px;
    border-radius: 8px;
}
QRadioButton::indicator:checked {
    background-color: #1f2937;
    border: 2px solid #1f2937;
}
QRadioButton::indicator:unchecked {
    background-color: white;
    border: 2px solid #d1d5db;
}
QCheckBox::indicator {
    width: 14px;
    height: 14px;
    border-radius: 3px;
}
QCheckBox::indicator:checked {
    background-color: #1f2937;
    border: 2px solid #1f2937;
}
QCheckBox::indicator:unchecked {
    background-color: white;
    border: 2px solid #d1d5db;
}

/* ── 스크롤바 ── */
QScrollArea { border: none; background-color: transparent; }
QScrollBar:vertical {
    background-color: #f3f4f6;
    width: 8px;
    border-radius: 4px;
    margin: 2px;
}
QScrollBar::handle:vertical {
    background-color: #9ca3af;
    border-radius: 4px;
    min-height: 24px;
}
QScrollBar::handle:vertical:hover { background-color: #6b7280; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0px; }
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: none; }
QScrollBar:horizontal {
    background-color: #f3f4f6;
    height: 8px;
    border-radius: 4px;
    margin: 2px;
}
QScrollBar::handle:horizontal {
    background-color: #9ca3af;
    border-radius: 4px;
    min-width: 24px;
}
QScrollBar::handle:horizontal:hover { background-color: #6b7280; }
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0px; }
QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal { background: none; }
"""


# ──────────────────────────────────────────────────────────────────────────────
# 테이블 Enter키 → 다음 셀 이동 delegate
# ──────────────────────────────────────────────────────────────────────────────

class _NextCellDelegate(QStyledItemDelegate):
    """Enter/Return 키로 편집 완료 후 다음 셀로 자동 이동."""

    def eventFilter(self, editor, event):
        if event.type() == QEvent.KeyPress and event.key() in (Qt.Key_Return, Qt.Key_Enter):
            tbl = self.parent()
            self.commitData.emit(editor)
            self.closeEditor.emit(editor, QStyledItemDelegate.NoHint)
            row = tbl.currentRow()
            col = tbl.currentColumn() + 1
            if col >= tbl.columnCount():
                col = 0
                row += 1
            if row < tbl.rowCount():
                tbl.setCurrentCell(row, col)
                tbl.edit(tbl.model().index(row, col))
            return True
        return super().eventFilter(editor, event)


class _MappingComboDelegate(QStyledItemDelegate):
    """재분류 이름 열 전용 — CN표 토지이용분류 드롭다운 + Enter키 이동."""

    def createEditor(self, parent, option, index):
        combo = QComboBox(parent)
        combo.setEditable(False)
        # 매 호출 시 최신 CN표 목록 로드
        dialog = self.parent()
        while dialog and not isinstance(dialog, CnCalculatorDialog):
            dialog = dialog.parent()
        if dialog:
            names = dialog._get_cn_land_use_names()
            combo.addItem('')
            combo.addItems(names)
        combo.setStyleSheet(
            "QComboBox { border: 1px solid #d1d5db; border-radius: 3px; padding: 1px 4px; }"
        )
        # 편집 진입 시 자동으로 드롭다운 펼치기
        from qgis.PyQt.QtCore import QTimer
        QTimer.singleShot(0, combo.showPopup)
        return combo

    def setEditorData(self, editor, index):
        val = index.data(Qt.EditRole) or ''
        idx = editor.findText(str(val))
        editor.setCurrentIndex(idx if idx >= 0 else 0)

    def setModelData(self, editor, model, index):
        model.setData(index, editor.currentText(), Qt.EditRole)

    def updateEditorGeometry(self, editor, option, index):
        editor.setGeometry(option.rect)

    def eventFilter(self, obj, event):
        if event.type() == QEvent.KeyPress and event.key() in (Qt.Key_Return, Qt.Key_Enter):
            self.commitData.emit(obj)
            self.closeEditor.emit(obj)
            # Move to next row, same column
            table = self.parent()
            if table:
                cur = table.currentIndex()
                next_row = cur.row() + 1
                if next_row < table.model().rowCount():
                    table.setCurrentIndex(table.model().index(next_row, cur.column()))
            return True
        return super().eventFilter(obj, event)

    def paint(self, painter, option, index):
        # 우측 화살표를 위해 텍스트 영역을 좁혀서 기본 렌더
        from qgis.PyQt.QtWidgets import QStyle, QStyleOptionViewItem, QApplication
        from qgis.PyQt.QtCore import QRect
        opt = QStyleOptionViewItem(option)
        self.initStyleOption(opt, index)
        opt.rect = QRect(option.rect)
        opt.rect.setRight(option.rect.right() - 16)  # 텍스트 영역 축소
        super().paint(painter, opt, index)

        # 우측에 네이티브 스타일의 드롭다운 화살표
        arrow_opt = QStyleOptionViewItem(option)
        arrow_opt.rect = QRect(
            option.rect.right() - 14,
            option.rect.top(),
            14,
            option.rect.height(),
        )
        style = QApplication.style()
        style.drawPrimitive(QStyle.PE_IndicatorArrowDown, arrow_opt, painter)


# ──────────────────────────────────────────────────────────────────────────────
# CN값 참조 테이블 팝업
# ──────────────────────────────────────────────────────────────────────────────

class _CnRefDialog(QDialog):
    """CN값 참조 테이블 팝업 — 검색 + 더블클릭 자동입력."""

    value_selected = pyqtSignal(str)   # 더블클릭 시 토지이용분류명 전달

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("CN값 참조 테이블")
        self.setWindowFlags(self.windowFlags() | Qt.Window)
        self.resize(360, 550)
        self.setStyleSheet(
            "QDialog { background-color: #f9fafb; }"
            "QTableWidget { background-color: white; border: 1px solid #e5e7eb; border-radius: 4px; }"
            "QLineEdit { border: 1px solid #d1d5db; border-radius: 4px; padding: 6px 10px; }"
        )

        layout = QVBoxLayout(self)
        layout.setSpacing(10)
        layout.setContentsMargins(16, 14, 16, 14)
        from qgis.PyQt.QtWidgets import QLayout
        layout.setSizeConstraint(QLayout.SetNoConstraint)

        # 안내 라벨
        desc = QLabel("더블클릭하면 매핑 테이블의 현재 선택 행에 재분류명이 자동 입력됩니다.")
        desc.setStyleSheet("color: #6b7280; font-size: 12px;")
        desc.setWordWrap(True)
        layout.addWidget(desc)

        # 검색 + 새로고침
        search_row = QHBoxLayout()
        self.leSearch = QLineEdit()
        self.leSearch.setPlaceholderText("토지이용분류 검색...")
        self.leSearch.textChanged.connect(self._filter)
        search_row.addWidget(self.leSearch)

        self.btnRefresh = QPushButton("새로고침")
        self.btnRefresh.setStyleSheet(
            "QPushButton { border: 1px solid #d1d5db; color: #374151;"
            "  border-radius: 4px; padding: 6px 12px; background: white; }"
            "QPushButton:hover { background-color: #f3f4f6; }"
        )
        self.btnRefresh.setToolTip("CN값 편집 탭의 변경사항을 반영합니다")
        search_row.addWidget(self.btnRefresh)
        layout.addLayout(search_row)

        # 테이블
        self.tblRef = QTableWidget()
        self.tblRef.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tblRef.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tblRef.verticalHeader().setDefaultSectionSize(32)
        self.tblRef.verticalHeader().setVisible(False)
        self.tblRef.doubleClicked.connect(self._on_double_click)
        layout.addWidget(self.tblRef)

    def load_data(self, df):
        """pandas DataFrame으로 테이블 채우기."""
        tbl = self.tblRef
        tbl.blockSignals(True)
        cols = list(df.columns)
        tbl.setColumnCount(len(cols))
        tbl.setHorizontalHeaderLabels(cols)
        tbl.setRowCount(len(df))
        for r, (_, row) in enumerate(df.iterrows()):
            for c, val in enumerate(row):
                text = "" if pd.isna(val) else str(val)
                item = QTableWidgetItem(text)
                item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                tbl.setItem(r, c, item)
        tbl.blockSignals(False)
        tbl.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        for c in range(1, tbl.columnCount()):
            tbl.horizontalHeader().setSectionResizeMode(c, QHeaderView.ResizeToContents)

    def _filter(self, text):
        search = text.strip().lower()
        tbl = self.tblRef
        for r in range(tbl.rowCount()):
            item = tbl.item(r, 0)
            name = item.text().lower() if item else ''
            tbl.setRowHidden(r, search != '' and search not in name)

    def _on_double_click(self, index):
        item = self.tblRef.item(index.row(), 0)
        if item and item.text().strip():
            self.value_selected.emit(item.text().strip())


# ──────────────────────────────────────────────────────────────────────────────
# 백그라운드 워커 스레드
# ──────────────────────────────────────────────────────────────────────────────

class CnWorker(QThread):
    progress    = pyqtSignal(int, str)      # (퍼센트, 메시지)
    layer_ready = pyqtSignal(object, str)   # (QgsVectorLayer, 레이어명) — 단계별 즉시 표시
    finished    = pyqtSignal(object, list)  # (cn_input_layer, fail_list)
    error       = pyqtSignal(str)

    def __init__(self, input_layer, name_field, level,
                 data_source='db', soil_path=None, lc_path=None):
        super().__init__()
        self.input_layer = input_layer
        self.name_field  = name_field
        self.level       = level
        self.data_source = data_source
        self.soil_path   = soil_path
        self.lc_path     = lc_path

    def run(self):
        try:
            import processing as proc

            # ── 소유역 전체 영역 Union ─────────────────────────────────────
            self.progress.emit(3, "소유역 영역 계산 중...")
            dissolved = proc.run("native:dissolve", {
                'INPUT': self.input_layer,
                'FIELD': [],
                'OUTPUT': 'memory:'
            })['OUTPUT']

            if self.data_source == 'local':
                # ── ① 로컬 토양군 Clip ──────────────────────────────────
                self.progress.emit(8, "① 로컬 토양군 Clip 중...")
                soil_clipped = load_local_soil(self.soil_path, dissolved)
                self.progress.emit(22, f"   → {soil_clipped.featureCount()}개 피처")
                self.layer_ready.emit(soil_clipped, "토양군_clip")

                # ── ② 로컬 토지피복도 Clip + Dissolve ───────────────────
                self.progress.emit(26, f"② 로컬 토지피복도 Clip 중 (level={self.level})...")
                lc_clipped = load_local_land_cover(self.lc_path, dissolved, self.level)
                self.progress.emit(40, f"   → {lc_clipped.featureCount()}개 피처")
                self.layer_ready.emit(lc_clipped, "토지피복도_clip")

                # ── ③ 로컬 Intersection (토양군 × 토지피복도) ───────────
                self.progress.emit(44, "③ Intersection(토양군 × 토지피복도) 중...")
                soil_lc = get_local_soil_lc_intersection(soil_clipped, lc_clipped, self.level)
                self.progress.emit(68, f"   → {soil_lc.featureCount()} features")
                self.layer_ready.emit(soil_lc, "토양군_토지피복_교차")

                # ── ④ Intersection × 소유역계 ──────────────────────────
                self.progress.emit(72, "④ Intersection × 소유역계 중...")
                final_intersect = intersect_layers(soil_lc, self.input_layer, "최종교차_raw")
                self.progress.emit(95, f"   → {final_intersect.featureCount()} features")
                self.finished.emit(final_intersect, [])

            else:
                # ── 기존 DB 모드 (변경 없음) ────────────────────────────
                union_geom = None
                for feat in dissolved.getFeatures():
                    union_geom = feat.geometry()
                    break
                if not union_geom:
                    raise ValueError("소유역 레이어에서 영역을 읽을 수 없습니다.")

                srid = self.input_layer.crs().postgisSrid()
                if srid <= 0:
                    srid = 5186
                polygon_wkt = union_geom.asWkt()

                # ── ①②③ DB: 단일 연결로 토양군/토지피복도 clip + 교차분석 ────
                self.progress.emit(8, "PostGIS 공간분석 시작 (단일 연결)...")
                soil_clipped, lc_clipped, soil_lc = get_all_layers(polygon_wkt, srid, self.level)

                self.progress.emit(22, f"① 토양군 clip: {soil_clipped.featureCount()}개")
                self.layer_ready.emit(soil_clipped, "토양군_clip")

                self.progress.emit(40, f"② 토지피복도 clip: {lc_clipped.featureCount()}개")
                self.layer_ready.emit(lc_clipped, "토지피복도_clip")

                self.progress.emit(68, f"③ 교차 분석: {soil_lc.featureCount()} features")
                self.layer_ready.emit(soil_lc, "토양군_토지피복_교차")

                # ── ④ QGIS Intersection × 소유역계 ───────────────────────────
                self.progress.emit(72, "④ Intersection × 소유역계 중...")
                final_intersect = intersect_layers(soil_lc, self.input_layer, "최종교차_raw")
                self.progress.emit(95, f"   → {final_intersect.featureCount()} features")
                self.finished.emit(final_intersect, [])

        except Exception as e:
            logger.exception("워커 오류")
            self.error.emit(str(e))


# ──────────────────────────────────────────────────────────────────────────────
# 메인 다이얼로그
# ──────────────────────────────────────────────────────────────────────────────

class CnCalculatorDialog(QDialog, FORM_CLASS):

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface  = iface
        self.worker = None
        self.input_layer = None
        self._cn_table_loaded    = False
        self._mapping_tab_loaded = False
        self._final_intersect_layer = None
        self._last_level        = 'l1'
        self._last_name_field   = ''
        self._cn_ref_loaded     = False
        self._cn_ref_dirty      = False
        self._cn_ref_popup      = None
        self._cn_ref_df         = pd.DataFrame()
        self._deactivation_size = None
        self.setupUi(self)
        self._init_ui()
        self._connect_signals()

    # ── 포커스 복귀 시 레이아웃 재계산에 의한 세로 확장 방지 ────────────────

    def changeEvent(self, event):
        if event.type() == QEvent.ActivationChange:
            if not self.isActiveWindow():
                self._deactivation_size = self.size()
            elif self._deactivation_size is not None:
                saved = self._deactivation_size
                self._deactivation_size = None
                from qgis.PyQt.QtCore import QTimer
                QTimer.singleShot(0, lambda: self.resize(saved))
        super().changeEvent(event)


    # ── 초기화 ────────────────────────────────────────────────────────────────

    def _init_ui(self):
        self.setStyleSheet(DIALOG_STYLESHEET)
        self.progressBar.setValue(0)
        self._refresh_layer_list()
        self._toggle_input_mode()
        self._setup_data_source_card()
        self._init_cn_table_widget()
        self._setup_mapping_tab()
        self._enhance_recalc_tab()
        self._setup_memory_list_card()     # CN값 계산 탭: 저장된 CN 메모리 목록
        self._setup_report_tab()           # '보고서 출력' 탭 신설(출력 위젯 이동 + 단계 드롭다운)
        self._refresh_stage_combos()
        # 초기화 버튼 — Tab 0 버튼 행(hLayoutButtons)에 삽입
        self.btnReset = QPushButton("초기화")
        self.btnReset.setMinimumWidth(80)
        self.btnReset.setMinimumHeight(36)
        self.btnReset.setStyleSheet(
            "QPushButton {"
            "  border: 1px solid #dc2626; color: #dc2626; border-radius: 6px;"
            "  padding: 6px 16px; font-weight: 600; background: white;"
            "}"
            "QPushButton:hover { background-color: #fef2f2; }"
        )
        self.hLayoutButtons.insertWidget(0, self.btnReset)
        # 동적 탭/카드 삽입 후 레이아웃이 다이얼로그 최소 크기를 강제하지 않도록 설정
        if self.layout():
            from qgis.PyQt.QtWidgets import QLayout
            self.layout().setSizeConstraint(QLayout.SetNoConstraint)
        self.setMinimumSize(480, 600)
        self.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        self.resize(640, 1000)

    def _refresh_layer_list(self):
        self.cmbLayer.clear()
        for layer in QgsProject.instance().mapLayers().values():
            if (layer.type() == QgsMapLayerType.VectorLayer and
                    layer.geometryType() == QgsWkbTypes.PolygonGeometry):
                self.cmbLayer.addItem(layer.name(), layer.id())

    def _refresh_recalc_layer_list(self):
        # CN 결과 레이어 — 'cn값' 필드 보유(사용자 지정 이름 포함) 또는 'CN값_input*' 이름 + 피처수.
        self.cmbRecalcLayer.clear()
        for layer in QgsProject.instance().mapLayers().values():
            if layer.type() != QgsMapLayerType.VectorLayer:
                continue
            try:
                has_cn = layer.fields().indexOf("cn값") >= 0
            except Exception:
                has_cn = False
            if has_cn or layer.name().startswith("CN값_input"):
                try:
                    n = layer.featureCount()
                except Exception:
                    n = -1
                label = layer.name() if n < 0 else f"{layer.name()} · {n}피처"
                self.cmbRecalcLayer.addItem(label, layer.id())

    def _init_cn_table_widget(self):
        tbl = self.tblCnValues
        tbl.horizontalHeader().setSectionResizeMode(0, QHeaderView.Interactive)
        tbl.horizontalHeader().setMinimumSectionSize(40)
        for col in range(1, tbl.columnCount()):
            tbl.horizontalHeader().setSectionResizeMode(col, QHeaderView.ResizeToContents)
        tbl.verticalHeader().setDefaultSectionSize(32)
        tbl.setItemDelegate(_NextCellDelegate(tbl))

    # ── 시그널 연결 ───────────────────────────────────────────────────────────

    def _connect_signals(self):
        # Tab 1
        self.rbFile.toggled.connect(self._toggle_input_mode)
        self.btnBrowse.clicked.connect(self._browse_file)
        self.leFilePath.editingFinished.connect(self._on_file_path_changed)
        self.cmbLayer.currentIndexChanged.connect(self._on_layer_changed)
        self.btnRun.clicked.connect(self._run)
        self.btnClose.clicked.connect(self.close)
        self.btnReset.clicked.connect(self._reset_all)
        # Tab 2
        self.btnAddRow.clicked.connect(self._cn_add_row)
        self.btnDeleteRow.clicked.connect(self._cn_delete_row)
        self.btnReloadCn.clicked.connect(self._cn_reload)
        self.btnImportCn.clicked.connect(self._cn_import)
        self.btnSaveCn.clicked.connect(self._cn_export)
        # Tab 3 (CN값 계산)
        self.btnApplyCn.clicked.connect(self._apply_cn_calc)
        self.btnOutputDir.clicked.connect(self._browse_output_dir)
        self.btnExportResult1.clicked.connect(self._export_results)
        self.btnExportResult2.setVisible(False)
        # Tab 2: 토지이용 재분류
        self.btnMappingLoadLayer.clicked.connect(self._mapping_load_from_layer)
        self.btnMappingSave.clicked.connect(self._mapping_save)
        self.btnMappingClear.clicked.connect(self._mapping_clear)
        # Tab 1: CN표 참조 팝업
        self.btnCnRefPopup.clicked.connect(self._show_cn_ref_popup)
        # Tab 1: 매핑 유효성 검증
        self.tblMapping.cellChanged.connect(self._validate_mapping_cell)
        # Tab 2: CN표 편집 시 참조 팝업 dirty 플래그
        self.tblCnValues.cellChanged.connect(lambda: setattr(self, '_cn_ref_dirty', True))
        # 다음 단계 버튼
        # 탭 순서: 레이어(0) → CN값 편집(1) → 토지이용 재분류(2) → CN값 계산(3)
        self.btnNextStep0.clicked.connect(lambda: self.tabWidget.setCurrentIndex(TAB_CN_EDIT))
        self.btnNextStep2.clicked.connect(lambda: self.tabWidget.setCurrentIndex(TAB_MAPPING))
        self.btnNextStep1.clicked.connect(lambda: self.tabWidget.setCurrentIndex(TAB_RECALC))
        # 탭 전환
        self.tabWidget.currentChanged.connect(self._on_tab_changed)

    # ── 입력 처리 ─────────────────────────────────────────────────────────────

    def _toggle_input_mode(self):
        file_mode = self.rbFile.isChecked()
        self.leFilePath.setEnabled(file_mode)
        self.btnBrowse.setEnabled(file_mode)
        self.cmbLayer.setEnabled(not file_mode)
        if not file_mode:
            self._refresh_layer_list()
            self._populate_name_fields_from_layer()

    def _browse_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "소유역 레이어 선택", "",
            "벡터 파일 (*.shp *.gpkg *.geojson);;모든 파일 (*)"
        )
        if path:
            self.leFilePath.setText(path)
            self._on_file_path_changed()

    def _on_file_path_changed(self):
        path = self.leFilePath.text().strip()
        if not (path and os.path.exists(path)):
            return
        name = os.path.splitext(os.path.basename(path))[0]
        layer = QgsVectorLayer(path, name, "ogr")
        if not layer.isValid():
            return

        from qgis.core import QgsCoordinateReferenceSystem
        target_crs = QgsCoordinateReferenceSystem("EPSG:5186")
        if layer.crs() != target_crs:
            src_epsg = layer.crs().authid() or "알 수 없음"
            try:
                import processing
                result = processing.run("native:reprojectlayer", {
                    'INPUT': layer,
                    'TARGET_CRS': target_crs,
                    'OUTPUT': f'memory:{name}_5186'
                })
                layer = result['OUTPUT']
                layer.setName(f"{name}_5186")
                self._log(f"소유역 좌표계 변환: {src_epsg} → EPSG:5186 ({layer.featureCount()}개 피처)")
            except Exception as e:
                self._log(f"좌표계 변환 실패: {e} (원본 로드)")

        self._populate_name_fields(layer)

        # 캔버스 중복 방지: 동일 이름 메모리 레이어 제거 후 추가
        for lyr in list(QgsProject.instance().mapLayers().values()):
            if lyr.name() == layer.name() or (
                hasattr(lyr, 'source') and lyr.source() == layer.source()
            ):
                QgsProject.instance().removeMapLayer(lyr.id())
        QgsProject.instance().addMapLayer(layer)
        self._loaded_subbasin_layer = layer
        try:
            self.iface.setActiveLayer(layer)
            self.iface.zoomToActiveLayer()
        except Exception:
            pass

    def _on_layer_changed(self):
        if self.rbLayer.isChecked():
            self._populate_name_fields_from_layer()

    def _on_tab_changed(self, index):
        if index == TAB_CN_EDIT and not self._cn_table_loaded:
            self._load_cn_to_table()
        elif index == TAB_RECALC:
            self._refresh_recalc_layer_list()
            self._refresh_memory_list_ui()
        elif index == TAB_REPORT:
            self._refresh_stage_combos()
        elif index == TAB_MAPPING:
            if not self._mapping_tab_loaded:
                self._mapping_load_saved()
            if not self._cn_ref_loaded:
                self._load_cn_ref_table()
            elif self._cn_ref_dirty:
                self._sync_cn_ref_from_edit()

    def _populate_name_fields_from_layer(self):
        layer_id = self.cmbLayer.currentData()
        if layer_id:
            layer = QgsProject.instance().mapLayer(layer_id)
            if layer:
                self._populate_name_fields(layer)

    def _populate_name_fields(self, layer: QgsVectorLayer):
        self.cmbNameField.clear()
        for field in layer.fields():
            self.cmbNameField.addItem(field.name())

    # ── 데이터 소스 선택 ─────────────────────────────────────────────────────

    def _setup_data_source_card(self):
        """Tab 0에 데이터 소스 선택 카드를 동적으로 추가."""
        tab0 = self.tabWidget.widget(TAB_CALC)
        layout = tab0.layout()
        if layout is None:
            return

        card = QFrame()
        card.setObjectName("dataSourceCard")
        card.setStyleSheet(
            "QFrame#dataSourceCard {"
            "  background-color: white; border: 1px solid #e5e7eb; border-radius: 8px;"
            "}"
        )
        card_layout = QVBoxLayout(card)
        card_layout.setSpacing(8)
        card_layout.setContentsMargins(16, 14, 16, 14)

        # 카드 헤더
        title = QLabel("데이터 소스")
        title.setStyleSheet(
            "font-size: 14px; font-weight: bold; color: #374151; border: none;"
        )
        card_layout.addWidget(title)

        # 라디오 버튼 행
        radio_row = QHBoxLayout()
        from qgis.PyQt.QtWidgets import QButtonGroup
        self.rbSourceDB = QRadioButton("DB에서 가져오기")
        self.rbSourceLocal = QRadioButton("로컬 파일 사용")
        self.rbSourceDB.setChecked(True)
        self._source_group = QButtonGroup(self)
        self._source_group.addButton(self.rbSourceDB)
        self._source_group.addButton(self.rbSourceLocal)
        radio_row.addWidget(self.rbSourceDB)
        radio_row.addWidget(self.rbSourceLocal)
        radio_row.addStretch()
        card_layout.addLayout(radio_row)

        # 로컬 파일 입력 위젯 (초기 숨김)
        self._local_file_widget = QWidget()
        local_layout = QVBoxLayout(self._local_file_widget)
        local_layout.setContentsMargins(0, 4, 0, 0)
        local_layout.setSpacing(6)

        # 토양군 파일
        soil_row = QHBoxLayout()
        soil_lbl = QLabel("토양군 파일:")
        soil_lbl.setFixedWidth(80)
        soil_lbl.setStyleSheet("border: none;")
        self.leSoilPath = QLineEdit()
        self.leSoilPath.setPlaceholderText("토양군 SHP/GPKG 파일 선택...")
        self.btnBrowseSoil = QPushButton("찾아보기")
        soil_row.addWidget(soil_lbl)
        soil_row.addWidget(self.leSoilPath, 1)
        soil_row.addWidget(self.btnBrowseSoil)
        local_layout.addLayout(soil_row)

        # 토지피복도 파일
        lc_row = QHBoxLayout()
        lc_lbl = QLabel("토지피복도:")
        lc_lbl.setFixedWidth(80)
        lc_lbl.setStyleSheet("border: none;")
        self.leLcPath = QLineEdit()
        self.leLcPath.setPlaceholderText("토지피복도 SHP/GPKG 파일 선택...")
        self.btnBrowseLc = QPushButton("찾아보기")
        lc_row.addWidget(lc_lbl)
        lc_row.addWidget(self.leLcPath, 1)
        lc_row.addWidget(self.btnBrowseLc)
        local_layout.addLayout(lc_row)

        card_layout.addWidget(self._local_file_widget)
        self._local_file_widget.setVisible(False)

        # Insert card into Tab 0 layout - insert near top (index 0 or after header)
        layout.insertWidget(0, card)

        # Connect signals
        self.rbSourceLocal.toggled.connect(self._toggle_data_source)
        self.btnBrowseSoil.clicked.connect(lambda: self._browse_local_file(self.leSoilPath, "토양군"))
        self.btnBrowseLc.clicked.connect(lambda: self._browse_local_file(self.leLcPath, "토지피복도"))

    def _toggle_data_source(self, local_checked):
        """데이터 소스 전환 (DB ↔ 로컬)."""
        self._local_file_widget.setVisible(local_checked)

    def _browse_local_file(self, line_edit, label):
        """로컬 파일 찾아보기 다이얼로그."""
        path, _ = QFileDialog.getOpenFileName(
            self, f"{label} 파일 선택", "",
            "벡터 파일 (*.shp *.gpkg);;모든 파일 (*)"
        )
        if path:
            line_edit.setText(path)

    # ── 실행 ──────────────────────────────────────────────────────────────────

    def _get_level(self) -> str:
        if self.rbL2.isChecked(): return 'l2'
        if self.rbL3.isChecked(): return 'l3'
        return 'l1'

    def _get_input_layer(self) -> QgsVectorLayer:
        if self.rbFile.isChecked():
            path = self.leFilePath.text().strip()
            if not path:
                raise ValueError("파일 경로를 입력하세요.")
            layer = QgsVectorLayer(path, "소유역계", "ogr")
            if not layer.isValid():
                raise ValueError(f"레이어 로드 실패: {path}")
        else:
            layer_id = self.cmbLayer.currentData()
            if not layer_id:
                raise ValueError("레이어를 선택하세요.")
            layer = QgsProject.instance().mapLayer(layer_id)
            if not layer:
                raise ValueError("선택한 레이어를 찾을 수 없습니다.")

        # 좌표계가 EPSG:5186이 아니면 자동 변환
        from qgis.core import QgsCoordinateReferenceSystem
        target_crs = QgsCoordinateReferenceSystem("EPSG:5186")
        if layer.crs() != target_crs:
            src_epsg = layer.crs().authid() or "알 수 없음"
            self._log(f"  좌표계 변환: {src_epsg} → EPSG:5186")
            import processing
            result = processing.run("native:reprojectlayer", {
                'INPUT': layer,
                'TARGET_CRS': target_crs,
                'OUTPUT': 'memory:소유역계_5186'
            })
            layer = result['OUTPUT']
            self._log(f"  변환 완료: {layer.featureCount()}개 피처")

        return layer

    def _run(self):
        if not self.cmbNameField.currentText():
            QMessageBox.warning(self, "입력 오류", "소유역명 컬럼을 선택하세요.")
            return
        try:
            input_layer = self._get_input_layer()
        except ValueError as e:
            QMessageBox.warning(self, "입력 오류", str(e))
            return

        # 입력 레이어 저장 (유역합성 UI에서 소유역명 조회용)
        self.input_layer = input_layer

        # 데이터 소스 확인
        data_source = 'local' if self.rbSourceLocal.isChecked() else 'db'
        soil_path = None
        lc_path = None
        if data_source == 'local':
            soil_path = self.leSoilPath.text().strip()
            lc_path = self.leLcPath.text().strip()
            if not soil_path:
                QMessageBox.warning(self, "입력 오류", "토양군 파일 경로를 입력하세요.")
                return
            if not lc_path:
                QMessageBox.warning(self, "입력 오류", "토지피복도 파일 경로를 입력하세요.")
                return

        self.btnRun.setEnabled(False)
        self.progressBar.setValue(0)
        self.txtLog.clear()
        self._log("▶ 레이어 불러오기 시작")
        if data_source == 'local':
            self._log("  모드: 로컬 파일")
        else:
            self._log("  모드: PostGIS DB")
        self._log("  단계별 중간 레이어가 캔버스에 즉시 표시됩니다.")
        self._log("─" * 44)

        self.worker = CnWorker(
            input_layer,
            self.cmbNameField.currentText(),
            self._get_level(),
            data_source=data_source,
            soil_path=soil_path,
            lc_path=lc_path,
        )
        self.worker.progress.connect(self._on_progress)
        self.worker.layer_ready.connect(self._on_layer_ready)
        self.worker.finished.connect(self._on_finished)
        self.worker.error.connect(self._on_error)
        self.worker.start()

    # ── 워커 콜백 ─────────────────────────────────────────────────────────────

    def _on_progress(self, pct: int, msg: str):
        self.progressBar.setValue(pct)
        self._log(msg)

    def _on_layer_ready(self, layer, name: str):
        """단계별 중간 레이어를 QGIS 캔버스에 추가 (나중 생성 = 위)."""
        layer.setName(name)
        QgsProject.instance().addMapLayer(layer)
        self._log(f"   ✦ 레이어 추가됨: [{name}]")

    def _on_finished(self, final_intersect_layer, _fail_list):
        # 교차 레이어 저장 (CN값 계산 탭에서 사용)
        self._final_intersect_layer = final_intersect_layer
        self._last_level      = self.worker.level
        self._last_name_field = self.worker.name_field

        self.progressBar.setValue(100)
        self._log("━" * 44)
        self._log("✔ 완료! 중간 레이어가 캔버스에 추가되었습니다.")
        self._log("  → [CN값 계산] 탭으로 이동하여 CN값을 계산하세요.")
        self.btnRun.setEnabled(True)

    def _on_error(self, msg: str):
        self._log(f"[오류] {msg}")
        QMessageBox.critical(self, "오류 발생", msg)
        self.btnRun.setEnabled(True)
        self.progressBar.setValue(0)

    # ── 초기화 ────────────────────────────────────────────────────────────────

    def _reset_all(self):
        """워크플로우 전체를 초기 상태로 되돌린다."""
        reply = QMessageBox.question(
            self, "초기화 확인",
            "모든 작업 상태를 초기화하시겠습니까?\n"
            "(캔버스의 분석 레이어도 제거됩니다)",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if reply != QMessageBox.Yes:
            return

        # 1) 워커 중단
        if self.worker and self.worker.isRunning():
            self.worker.terminate()
            self.worker.wait()
        self.worker = None

        # 2) 캔버스에서 분석 레이어 제거
        remove_names = {"토양군_clip", "토지피복도_clip", "토양군_토지피복_교차", "CN값_input"}
        project = QgsProject.instance()
        for lyr in list(project.mapLayers().values()):
            if lyr.name() in remove_names:
                project.removeMapLayer(lyr.id())

        # 3) 상태 변수 리셋
        self.input_layer = None
        self._final_intersect_layer = None
        self._last_level = 'l1'
        self._last_name_field = ''
        self._cn_table_loaded = False
        self._mapping_tab_loaded = False
        self._cn_ref_loaded = False
        self._cn_ref_dirty = False
        self._cn_ref_df = pd.DataFrame()
        if self._cn_ref_popup is not None:
            self._cn_ref_popup.close()
            self._cn_ref_popup = None

        # 4) Tab 0 UI 리셋
        self.progressBar.setValue(0)
        self.txtLog.clear()
        self.leFilePath.clear()
        self.cmbNameField.clear()
        self.rbFile.setChecked(True)
        self.rbL1.setChecked(True)
        self.rbSourceDB.setChecked(True)
        self._toggle_input_mode()
        self.btnRun.setEnabled(True)
        self._refresh_layer_list()

        # 5) Tab 1 매핑 테이블 리셋
        self.tblMapping.setRowCount(0)

        # 6) Tab 2 CN값 테이블 리셋
        self.tblCnValues.setRowCount(0)
        self.tblCnValues.setColumnCount(0)

        # 7) Tab 3 리셋
        self.progressBarCalc.setValue(0)
        self.progressBarCalc.setVisible(False)
        self.txtRecalcLog.clear()
        self.leOutputDir.clear()
        self._refresh_recalc_layer_list()
        self.tblWsGroups.setRowCount(0)

        # 8) Tab 0으로 이동
        self.tabWidget.setCurrentIndex(TAB_CALC)
        self._log("초기화 완료. 처음부터 다시 시작할 수 있습니다.")

    # ── CN값 편집 탭 ──────────────────────────────────────────────────────────

    def _load_cn_to_table(self):
        try:
            df = load_cn_table(XLSX_PATH)
        except FileNotFoundError as e:
            QMessageBox.warning(self, "파일 없음", str(e))
            return
        except Exception as e:
            QMessageBox.critical(self, "로드 오류", str(e))
            return
        self._df_to_table(df)
        self._cn_table_loaded = True

    def _df_to_table(self, df: pd.DataFrame):
        tbl = self.tblCnValues
        tbl.blockSignals(True)
        cols = list(df.columns)
        tbl.setColumnCount(len(cols))
        tbl.setHorizontalHeaderLabels(cols)
        tbl.setRowCount(len(df))
        for r, (_, row) in enumerate(df.iterrows()):
            for c, val in enumerate(row):
                text = "" if pd.isna(val) else str(val)
                if c > 0 and text:
                    try:
                        text = str(int(float(text)))
                    except (ValueError, OverflowError):
                        pass
                item = QTableWidgetItem(text)
                if c > 0:
                    item.setTextAlignment(Qt.AlignCenter)
                tbl.setItem(r, c, item)
        tbl.horizontalHeader().setSectionResizeMode(0, QHeaderView.Interactive)
        for c in range(1, tbl.columnCount()):
            tbl.horizontalHeader().setSectionResizeMode(c, QHeaderView.ResizeToContents)
        tbl.resizeColumnToContents(0)
        tbl.setColumnWidth(0, max(tbl.columnWidth(0), 160))
        tbl.blockSignals(False)

    def _get_cn_table_from_widget(self) -> pd.DataFrame:
        """현재 CN값 편집 테이블 위젯 내용을 DataFrame으로 반환."""
        tbl = self.tblCnValues
        if tbl.rowCount() == 0:
            return pd.DataFrame()
        headers = []
        for c in range(tbl.columnCount()):
            h = tbl.horizontalHeaderItem(c)
            headers.append(h.text() if h else f"col_{c}")
        data = []
        for r in range(tbl.rowCount()):
            row_data = []
            for c in range(tbl.columnCount()):
                item = tbl.item(r, c)
                row_data.append(item.text() if item else "")
            data.append(row_data)
        df = pd.DataFrame(data, columns=headers)
        for col in headers[1:]:
            df[col] = pd.to_numeric(df[col], errors='coerce')
        return df

    def _get_cn_land_use_names(self) -> list:
        """CN값 테이블에서 토지이용분류 목록 반환."""
        # 위젯 테이블에 데이터가 있으면 거기서 로드
        tbl = self.tblCnValues
        if tbl.rowCount() > 0:
            names = []
            for r in range(tbl.rowCount()):
                item = tbl.item(r, 0)
                if item and item.text().strip():
                    names.append(item.text().strip())
            if names:
                return names
        # 파일에서 폴백 로드
        try:
            from .core.cn_matcher import load_cn_table, XLSX_PATH
            df = load_cn_table(XLSX_PATH)
            return [str(v) for v in df.iloc[:, 0].dropna().tolist() if str(v).strip()]
        except Exception:
            return []

    def _cn_export(self):
        """현재 CN값 테이블을 사용자가 지정한 파일로 내보내기."""
        tbl = self.tblCnValues
        if tbl.rowCount() == 0:
            QMessageBox.warning(self, "내보내기 불가", "테이블에 데이터가 없습니다.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "CN값 테이블 내보내기", "cn_value_custom.xlsx",
            "Excel 파일 (*.xlsx)"
        )
        if not path:
            return
        if not path.lower().endswith('.xlsx'):
            path += '.xlsx'
        df = self._get_cn_table_from_widget()
        try:
            df.to_excel(path, index=False)
            QMessageBox.information(self, "내보내기 완료", f"저장 완료:\n{path}")
        except Exception as e:
            QMessageBox.critical(self, "내보내기 오류", str(e))

    def _cn_import(self):
        """사용자가 지정한 xlsx 파일에서 CN값 테이블 불러오기."""
        path, _ = QFileDialog.getOpenFileName(
            self, "CN값 테이블 불러오기", "",
            "Excel 파일 (*.xlsx)"
        )
        if not path:
            return
        try:
            df = load_cn_table(path)
            self._df_to_table(df)
            self._cn_table_loaded = True
            QMessageBox.information(self, "불러오기 완료", f"불러오기 완료:\n{path}")
            self._cn_ref_dirty = True
        except Exception as e:
            QMessageBox.critical(self, "불러오기 오류", str(e))

    def _cn_add_row(self):
        tbl = self.tblCnValues
        row = tbl.rowCount()
        tbl.insertRow(row)
        for c in range(tbl.columnCount()):
            item = QTableWidgetItem("")
            if c > 0:
                item.setTextAlignment(Qt.AlignCenter)
            tbl.setItem(row, c, item)
        tbl.scrollToBottom()
        tbl.setCurrentCell(row, 0)
        self._cn_ref_dirty = True

    def _cn_delete_row(self):
        tbl = self.tblCnValues
        if not tbl.selectedItems():
            QMessageBox.information(self, "행 삭제", "삭제할 행을 먼저 선택하세요.")
            return
        row = tbl.currentRow()
        name_item = tbl.item(row, 0)
        name = name_item.text() if name_item else f"행 {row + 1}"
        reply = QMessageBox.question(
            self, "행 삭제 확인",
            f"'{name}' 항목을 삭제하시겠습니까?",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            tbl.removeRow(row)
            self._cn_ref_dirty = True

    def _cn_reload(self):
        reply = QMessageBox.question(
            self, "기본값 불러오기",
            "현재 편집 내용이 사라지고 기본 CN값(cn_value.xlsx)으로 초기화됩니다.\n계속하시겠습니까?",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            self._cn_table_loaded = False
            self._load_cn_to_table()
            self._cn_ref_dirty = True

    # ── 재계산 탭 ─────────────────────────────────────────────────────────────

    def _browse_output_dir(self):
        folder = QFileDialog.getExistingDirectory(
            self, "결과 저장 폴더 선택", self.leOutputDir.text() or ""
        )
        if folder:
            self.leOutputDir.setText(folder)

    def _get_recalc_layer(self):
        """cmbRecalcLayer에서 선택된 CN값_input 레이어 반환."""
        layer_id = self.cmbRecalcLayer.currentData()
        if not layer_id:
            raise ValueError("CN값_input 레이어를 선택하세요.")
        layer = QgsProject.instance().mapLayer(layer_id)
        if not layer:
            raise ValueError("선택한 레이어를 찾을 수 없습니다. 레이어 목록을 새로고침하세요.")
        return layer

    def _get_output_dir(self):
        """출력 폴더 경로 반환 (없으면 ValueError)."""
        folder = self.leOutputDir.text().strip()
        if not folder:
            raise ValueError("결과 저장 폴더를 선택하세요.")
        if not os.path.isdir(folder):
            raise ValueError(f"존재하지 않는 폴더입니다: {folder}")
        return folder

    def _export_results(self):
        # 3단계 비교 모드면 단계별 경로로 분기(단일단계 경로는 그대로 보존).
        if getattr(self, 'chkStaged', None) is not None and self.chkStaged.isChecked():
            self._export_staged()
            return
        try:
            layer = self._get_recalc_layer()
            folder = self._get_output_dir()
        except ValueError as e:
            QMessageBox.warning(self, "입력 오류", str(e))
            return

        want_excel = getattr(self, 'chkExportExcel', None) is None or self.chkExportExcel.isChecked()
        want_hwp = getattr(self, 'chkExportHwp', None) is not None and self.chkExportHwp.isChecked()
        if not (want_excel or want_hwp):
            QMessageBox.warning(self, "입력 오류", "Excel 또는 한글 중 하나 이상 선택해야 합니다.")
            return

        self._recalc_log("▶ 결과 내보내기 시작...")
        try:
            result1_data, result2_data, null_cn_rows = calculate_results(layer)
            self._warn_null_cn(null_cn_rows)

            groups = self._get_watershed_groups()
            grouped_r1, grouped_r2 = None, None
            if groups:
                try:
                    self._recalc_log(f"  유역합성 {len(groups)}개 그룹 계산 중...")
                    grouped_r1, grouped_r2 = calculate_grouped_results(layer, groups)
                    self._recalc_log(f"  유역합성 계산 완료: {len(grouped_r1)}개 그룹")
                except Exception as e:
                    logger.exception("유역합성 계산 오류")
                    self._recalc_log(f"  [경고] 유역합성 계산 실패: {e}")
                    self._recalc_log(f"  → 개별 소유역 결과만 내보냅니다.")
                    grouped_r1, grouped_r2 = None, None
        except Exception as e:
            logger.exception("결과 계산 오류")
            self._recalc_log(f"[오류] {e}")
            QMessageBox.critical(self, "오류", str(e))
            return

        summary_lines: list[str] = []
        excel_path: str = ""

        # Excel 출력
        if want_excel:
            excel_path = os.path.join(folder, "result.xlsx")
            try:
                self._recalc_log(f"  Excel 저장 중... ({excel_path})")
                export_results(result1_data, result2_data, excel_path,
                               grouped_result1=grouped_r1, grouped_result2=grouped_r2)
                self._recalc_log(f"  ✔ Excel 저장 완료")
                summary_lines.append(f"Excel: {excel_path}")
                self._load_xlsx_as_layer(excel_path, "result1", sheet="result1")
            except Exception as e:
                logger.exception("Excel 내보내기 오류")
                self._recalc_log(f"  [오류] Excel 저장 실패: {e}")
                summary_lines.append(f"Excel: 실패 — {e}")

        # HWP 출력 (부분 실패 허용) — HWPX(zip+xml) 포맷으로 저장
        if want_hwp:
            hwp_path = os.path.join(folder, "result.hwpx")
            template = DEFAULT_HWP_TEMPLATE        # 내장 템플릿 고정 사용
            try:
                # 순수 Python(lxml) 렌더러 — 한컴오피스/COM 불필요.
                from .core.hwpx_writer import render_hwpx, HwpxRenderError
                # 기준표(표 4-18)는 국가표준 고정표를 build_analysis_result가 자동 로드한다
                # (cn_reference 미전달). 사용자 편집 CN값(Tab2)은 CN 매칭에만 사용.
                meta = ProjectMeta(
                    project_name=os.path.basename(folder),
                    land_cover_level=self._get_selected_level_key(),
                    data_source=self._get_selected_data_source(),
                )
                result = build_analysis_result(
                    result1_data, result2_data,
                    meta=meta,
                    grouped_result1=grouped_r1, grouped_result2=grouped_r2,
                    null_cn_rows=null_cn_rows,
                )
                self._recalc_log(f"  HWPX 저장 중... ({hwp_path})")
                render_hwpx(result, template, hwp_path)
                self._recalc_log(f"  ✔ HWP 저장 완료")
                summary_lines.append(f"HWP: {hwp_path}")
            except Exception as e:
                logger.exception("HWP 내보내기 오류")
                self._recalc_log(f"  [경고] HWP 저장 실패: {e}")
                summary_lines.append(f"HWP: 실패 — {e}")

        msg = "\n".join(summary_lines) or "출력된 파일이 없습니다."
        QMessageBox.information(self, "저장 결과", msg)

    def _collect_cn_reference_rows(self) -> list:
        """Tab 2 CN값 편집표 → [(land_use, a, b, c, d), ...] (HWP 기준표용)."""
        rows: list[tuple] = []
        if not hasattr(self, 'tblCnValues'):
            return rows
        t = self.tblCnValues
        for r in range(t.rowCount()):
            lu_item = t.item(r, 0)
            if lu_item is None or not lu_item.text().strip():
                continue
            def _int_or_none(c):
                it = t.item(r, c)
                if it is None or not it.text().strip():
                    return None
                try:
                    return int(float(it.text().strip()))
                except ValueError:
                    return None
            rows.append((
                lu_item.text().strip(),
                _int_or_none(1), _int_or_none(2), _int_or_none(3), _int_or_none(4),
            ))
        return rows

    def _get_selected_level_key(self) -> str:
        for key, rb_name in (('l1', 'rbL1'), ('l2', 'rbL2'), ('l3', 'rbL3')):
            rb = getattr(self, rb_name, None)
            if rb is not None and rb.isChecked():
                return key
        return 'l3'

    def _get_selected_data_source(self) -> str:
        if getattr(self, 'rbSourceLocal', None) is not None and self.rbSourceLocal.isChecked():
            return 'local'
        return 'db'

    # ── 토지이용 재분류 탭 ────────────────────────────────────────────────────

    def _setup_mapping_tab(self):
        """토지이용 재분류 탭을 프로그래매틱으로 생성하여 tabWidget에 삽입."""
        tab = QWidget()
        tab.setStyleSheet("background-color: #f9fafb;")
        outer = QVBoxLayout(tab)
        outer.setSpacing(12)
        outer.setContentsMargins(16, 16, 16, 16)

        # ── 설명 카드 ──────────────────────────────────────────────────
        desc_card = QFrame()
        desc_card.setObjectName("mappingDescCard")
        desc_card.setStyleSheet(
            "QFrame#mappingDescCard {"
            "  background-color: #fef9c3; border: 1px solid #fde047;"
            "  border-radius: 8px;"
            "}"
        )
        desc_layout = QHBoxLayout(desc_card)
        desc_layout.setContentsMargins(14, 10, 14, 10)
        desc_layout.setSpacing(10)

        icon_lbl = QLabel("ℹ")
        icon_lbl.setStyleSheet("font-size: 14px; color: #854d0e; border: none;")
        icon_lbl.setFixedWidth(18)
        desc_layout.addWidget(icon_lbl)

        info_lbl = QLabel(
            "토지피복도 원본 이름 → 재분류 이름으로 매핑합니다. "
            "재분류 이름은 CN값 편집 탭의 토지이용분류 목록에서만 선택할 수 있습니다. "
            "오른쪽 CN표 참조 버튼으로 CN값을 확인할 수 있습니다."
        )
        info_lbl.setWordWrap(True)
        info_lbl.setStyleSheet("color: #854d0e; font-size: 12px; border: none;")
        desc_layout.addWidget(info_lbl, 1)
        outer.addWidget(desc_card)

        # ── 매핑 테이블 카드 ───────────────────────────────────────────
        table_card = QFrame()
        table_card.setObjectName("mappingTableCard")
        table_card.setStyleSheet(
            "QFrame#mappingTableCard {"
            "  background-color: white; border: 1px solid #e5e7eb; border-radius: 8px;"
            "}"
        )
        table_layout = QVBoxLayout(table_card)
        table_layout.setSpacing(10)
        table_layout.setContentsMargins(16, 14, 16, 14)

        # 카드 헤더 + 버튼 행
        header_row = QHBoxLayout()
        header_row.setSpacing(8)
        card_title = QLabel("토지이용 재분류 매핑")
        card_title.setStyleSheet(
            "font-size: 14px; font-weight: bold; color: #374151; border: none;"
        )
        header_row.addWidget(card_title)
        header_row.addStretch()

        self.btnMappingLoadLayer = QPushButton("레이어에서 불러오기")
        header_row.addWidget(self.btnMappingLoadLayer)
        self.btnCnRefPopup = QPushButton("CN표 참조")
        self.btnCnRefPopup.setStyleSheet(
            "QPushButton { border: 1px solid #d1d5db; color: #374151;"
            "  border-radius: 6px; padding: 5px 12px; background: white; }"
            "QPushButton:hover { background-color: #f3f4f6; }"
        )
        header_row.addWidget(self.btnCnRefPopup)
        table_layout.addLayout(header_row)

        # 테이블
        self.tblMapping = QTableWidget(0, 2)
        self.tblMapping.setHorizontalHeaderLabels(['원본 이름', '재분류 이름'])
        self.tblMapping.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.tblMapping.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.tblMapping.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tblMapping.verticalHeader().setDefaultSectionSize(32)
        self.tblMapping.verticalHeader().setVisible(False)
        self.tblMapping.setItemDelegateForColumn(0, _NextCellDelegate(self.tblMapping))
        self.tblMapping.setItemDelegateForColumn(1, _MappingComboDelegate(self.tblMapping))
        table_layout.addWidget(self.tblMapping)

        # 저장/초기화 버튼 행
        btn_row = QHBoxLayout()
        btn_row.setSpacing(8)
        btn_row.addStretch()
        self.btnMappingClear = QPushButton("초기화")
        self.btnMappingSave  = QPushButton("저장")
        self.btnMappingSave.setStyleSheet(
            "QPushButton { background-color: #1f2937; color: white;"
            "  border: none; border-radius: 6px; padding: 6px 20px; font-weight: 600; }"
            "QPushButton:hover { background-color: #374151; }"
        )
        btn_row.addWidget(self.btnMappingClear)
        btn_row.addWidget(self.btnMappingSave)
        table_layout.addLayout(btn_row)

        outer.addWidget(table_card, 1)

        # 다음 단계 버튼
        next_row = QHBoxLayout()
        next_row.addStretch()
        self.btnNextStep1 = QPushButton("다음 단계 →")
        self.btnNextStep1.setMinimumHeight(34)
        self.btnNextStep1.setMinimumWidth(110)
        self.btnNextStep1.setStyleSheet(
            "QPushButton { border: 1px solid #374151; color: #374151;"
            "  border-radius: 6px; padding: 6px 16px; font-weight: 600; background: white; }"
            "QPushButton:hover { background-color: #f3f4f6; }"
        )
        next_row.addWidget(self.btnNextStep1)
        outer.addLayout(next_row)

        self.tabWidget.insertTab(TAB_MAPPING, tab, "토지이용 재분류")
        self.tabWidget.setTabText(TAB_RECALC, "CN값 계산")
        self.tabWidget.tabBar().setUsesScrollButtons(True)

    def _mapping_load_saved(self):
        """저장된 land_use_mapping.json을 테이블에 로드.
        CN표에 없는 재분류 값은 빈 값으로 표시(자유입력 금지 정책)."""
        from .core.land_use_mapper import load_mapping
        mapping = load_mapping()
        valid_names = set(self._get_cn_land_use_names())
        self.tblMapping.setRowCount(0)
        for original, remapped in mapping.items():
            r = self.tblMapping.rowCount()
            self.tblMapping.insertRow(r)
            self.tblMapping.setItem(r, 0, QTableWidgetItem(original))
            shown = remapped if remapped in valid_names else ''
            self.tblMapping.setItem(r, 1, QTableWidgetItem(shown))
        self._mapping_tab_loaded = True

    def _mapping_load_from_layer(self):
        """캔버스의 토양군_토지피복_교차 레이어에서 선택된 분류 수준의 고유 토지이용 값을 채운다."""
        intersect_lyrs = [
            l for l in QgsProject.instance().mapLayers().values()
            if (l.type() == QgsMapLayerType.VectorLayer and l.name() == "토양군_토지피복_교차")
        ]
        if not intersect_lyrs:
            QMessageBox.information(
                self, "레이어 없음",
                "캔버스에 토양군_토지피복_교차 레이어가 없습니다.\n"
                "먼저 [레이어 불러오기] 탭에서 실행하세요."
            )
            return

        level = self._get_level()
        col_name = {'l1': 'l1_name', 'l2': 'l2_name', 'l3': 'l3_name'}[level]

        layer = intersect_lyrs[0]
        field_names = [f.name() for f in layer.fields()]
        if col_name not in field_names:
            QMessageBox.warning(
                self, "칼럼 없음",
                f"레이어에 '{col_name}' 칼럼이 없습니다.\n"
                f"분류 수준({level})에 맞는 레이어인지 확인하세요."
            )
            return

        # 기존 재분류 이름 보존
        existing = self._mapping_table_to_dict()

        unique_values = sorted({
            str(f[col_name]) for f in layer.getFeatures()
            if f[col_name] and str(f[col_name]) not in ('NULL', 'None', '')
        })

        self.tblMapping.setRowCount(0)
        for val in unique_values:
            r = self.tblMapping.rowCount()
            self.tblMapping.insertRow(r)
            self.tblMapping.setItem(r, 0, QTableWidgetItem(val))
            self.tblMapping.setItem(r, 1, QTableWidgetItem(existing.get(val, '')))

    def _mapping_table_to_dict(self) -> dict:
        """현재 테이블을 {원본: 재분류} dict로 변환. 재분류 이름이 빈 행은 제외."""
        mapping = {}
        for r in range(self.tblMapping.rowCount()):
            orig  = (self.tblMapping.item(r, 0) or QTableWidgetItem()).text().strip()
            remap = (self.tblMapping.item(r, 1) or QTableWidgetItem()).text().strip()
            if orig and remap:
                mapping[orig] = remap
        return mapping

    def _mapping_save(self):
        from .core.land_use_mapper import save_mapping
        mapping = self._mapping_table_to_dict()
        try:
            save_mapping(mapping)
            QMessageBox.information(
                self, "저장 완료",
                f"토지이용 재분류 매핑이 저장되었습니다.\n적용 항목: {len(mapping)}개"
            )
        except Exception as e:
            QMessageBox.critical(self, "저장 오류", str(e))

    def _load_cn_ref_table(self):
        """CN참조 데이터를 DataFrame으로 로드 (팝업용)."""
        from .core.cn_matcher import load_cn_table, XLSX_PATH
        try:
            self._cn_ref_df = load_cn_table(XLSX_PATH)
        except Exception:
            df = self._get_cn_table_from_widget()
            self._cn_ref_df = df if df is not None and not df.empty else pd.DataFrame()
        self._cn_ref_loaded = True

    def _show_cn_ref_popup(self):
        """CN값 참조 테이블 팝업을 표시."""
        data_changed = False
        if not self._cn_ref_loaded:
            self._load_cn_ref_table()
            data_changed = True
        elif self._cn_ref_dirty:
            self._sync_cn_ref_from_edit()
            data_changed = True

        if not hasattr(self, '_cn_ref_popup') or self._cn_ref_popup is None:
            self._cn_ref_popup = _CnRefDialog(self)
            self._cn_ref_popup.value_selected.connect(self._on_cn_ref_value_selected)
            self._cn_ref_popup.btnRefresh.clicked.connect(self._refresh_cn_ref_popup)
            data_changed = True

        if data_changed and not self._cn_ref_df.empty:
            self._cn_ref_popup.load_data(self._cn_ref_df)

        self._cn_ref_popup.show()
        self._cn_ref_popup.raise_()
        self._cn_ref_popup.activateWindow()

    def _sync_cn_ref_from_edit(self):
        """Tab 2에서 편집된 CN표를 참조 데이터에 동기화."""
        df = self._get_cn_table_from_widget()
        if df is not None and not df.empty:
            self._cn_ref_df = df
        self._cn_ref_dirty = False

    def _refresh_cn_ref_popup(self):
        """CN참조 팝업의 새로고침 버튼 — Tab 2 편집 내용을 즉시 반영."""
        self._sync_cn_ref_from_edit()
        if self._cn_ref_popup and not self._cn_ref_df.empty:
            self._cn_ref_popup.load_data(self._cn_ref_df)

    def _mapping_clear(self):
        reply = QMessageBox.question(
            self, "초기화 확인",
            "모든 매핑을 삭제하고 저장하시겠습니까?",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            self.tblMapping.setRowCount(0)
            from .core.land_use_mapper import save_mapping
            save_mapping({})

    def _validate_mapping_cell(self, row, col):
        """재분류명 유효성 → 셀 배경색 표시."""
        if col != 1:
            return
        item = self.tblMapping.item(row, col)
        if not item:
            return
        text = item.text().strip()
        if not text:
            item.setBackground(Qt.transparent)
            item.setToolTip('')
            return
        cn_names = self._get_cn_land_use_names()
        if text in cn_names:
            from qgis.PyQt.QtGui import QColor
            item.setBackground(QColor('#f0fdf4'))
            item.setToolTip('')
        else:
            from qgis.PyQt.QtGui import QColor
            item.setBackground(QColor('#fef2f2'))
            item.setToolTip(f'CN값 테이블에 "{text}" 항목이 없습니다')

    def _on_cn_ref_value_selected(self, lu_name):
        """CN표 참조 팝업에서 선택된 값을 매핑 테이블에 입력."""
        cur_row = self.tblMapping.currentRow()
        if cur_row < 0:
            return
        target_item = self.tblMapping.item(cur_row, 1)
        if target_item is None:
            target_item = QTableWidgetItem('')
            self.tblMapping.setItem(cur_row, 1, target_item)
        target_item.setText(lu_name)
        # 다음 행으로 자동 이동
        next_row = cur_row + 1
        if next_row < self.tblMapping.rowCount():
            self.tblMapping.setCurrentCell(next_row, 1)

    def _setup_output_format_row(self):
        """출력 포맷 선택 행을 'btnExportResult1' 상단에 삽입.

        체크박스: ☑ Excel(.xlsx) / ☐ 한글(.hwp)
        HWP 체크 시 템플릿 경로(leHwpTemplate) + 찾아보기 버튼 활성화.
        """
        # btnExportResult1 의 부모 레이아웃을 찾아 그 위에 새 행 삽입
        parent_layout = self.btnExportResult1.parentWidget().layout() \
            if self.btnExportResult1.parentWidget() else None
        if parent_layout is None:
            logger.warning("출력 포맷 행 삽입 실패: btnExportResult1 부모 레이아웃 없음")
            return

        format_row = QHBoxLayout()
        format_row.setSpacing(8)

        lbl = QLabel("출력 포맷")
        lbl.setStyleSheet("color: #6b7280; font-size: 13px; border: none;")
        lbl.setMinimumWidth(110)
        format_row.addWidget(lbl)

        self.chkExportExcel = QCheckBox("Excel (.xlsx)")
        self.chkExportExcel.setChecked(True)
        self.chkExportHwp = QCheckBox("한글 (.hwpx)")
        self.chkExportHwp.setChecked(False)
        format_row.addWidget(self.chkExportExcel)
        format_row.addWidget(self.chkExportHwp)
        format_row.addStretch()

        # HWP 템플릿 경로 행
        tmpl_row = QHBoxLayout()
        tmpl_row.setSpacing(8)
        lbl_t = QLabel("HWP 템플릿")
        lbl_t.setStyleSheet("color: #6b7280; font-size: 13px; border: none;")
        lbl_t.setMinimumWidth(110)
        tmpl_row.addWidget(lbl_t)

        self.leHwpTemplate = QLineEdit()
        self.leHwpTemplate.setText(DEFAULT_HWP_TEMPLATE)
        self.leHwpTemplate.setPlaceholderText("templates/v1.0/cn_report.hwpx")
        tmpl_row.addWidget(self.leHwpTemplate)

        self.btnHwpTemplate = QPushButton("찾아보기")
        self.btnHwpTemplate.setMaximumWidth(80)
        self.btnHwpTemplate.clicked.connect(self._browse_hwp_template)
        tmpl_row.addWidget(self.btnHwpTemplate)

        # 초기 상태: HWP 체크 해제 → 템플릿 행 비활성
        self.leHwpTemplate.setEnabled(False)
        self.btnHwpTemplate.setEnabled(False)
        self.chkExportHwp.toggled.connect(self._on_hwp_toggled)

        # 삽입: btnExportResult1 의 인덱스 찾아 그 앞에 두 행 추가
        btn_index = -1
        for i in range(parent_layout.count()):
            item = parent_layout.itemAt(i)
            w = item.widget() if item is not None else None
            # btnExportResult1가 직접 위젯이 아닐 수 있음(수평 레이아웃 내부) — 직접 비교
            if w is self.btnExportResult1:
                btn_index = i
                break
            # 수평 레이아웃 내부 검사
            child_layout = item.layout() if item is not None else None
            if child_layout is not None:
                for j in range(child_layout.count()):
                    if child_layout.itemAt(j).widget() is self.btnExportResult1:
                        btn_index = i
                        break
            if btn_index >= 0:
                break

        if btn_index < 0:
            # 못 찾으면 끝에 붙임
            parent_layout.addLayout(format_row)
            parent_layout.addLayout(tmpl_row)
        else:
            parent_layout.insertLayout(btn_index, format_row)
            parent_layout.insertLayout(btn_index + 1, tmpl_row)

    def _on_hwp_toggled(self, checked: bool):
        self.leHwpTemplate.setEnabled(checked)
        self.btnHwpTemplate.setEnabled(checked)

    def _browse_hwp_template(self):
        start = self.leHwpTemplate.text().strip() or DEFAULT_HWP_TEMPLATE
        path, _ = QFileDialog.getOpenFileName(
            self, "HWP 템플릿 선택", start, "한글 파일 (*.hwpx *.hwp)"
        )
        if path:
            self.leHwpTemplate.setText(path)

    # ── 개발 전/중/후 3단계 비교 보고서 ───────────────────────────────────────

    def _setup_memory_list_card(self):
        """CN값 계산 탭: 저장된 CN 메모리 목록(이름·요약 + 지우기).

        CN값 계산 실행 시 입력한 레이어 이름으로 결과가 메모리에 저장된다.
        개발 전/중/후 단계 선택·보고서 출력은 [보고서 출력] 탭에서 한다.
        """
        self._memory_pool = {}
        target = getattr(self, '_recalc_content_layout', None) \
            or self.tabWidget.widget(TAB_RECALC).layout()

        card = QFrame()
        card.setObjectName("memListCard")
        card.setStyleSheet(
            "QFrame#memListCard { background-color: white; border: 1px solid #e5e7eb;"
            "  border-radius: 8px; }"
        )
        v = QVBoxLayout(card)
        v.setSpacing(8)
        v.setContentsMargins(16, 14, 16, 14)

        title = QLabel("저장된 CN 메모리")
        title.setStyleSheet("font-size: 14px; font-weight: bold; color: #374151; border: none;")
        v.addWidget(title)
        info = QLabel(
            "[CN값 계산 실행] 시 입력한 '레이어 이름'으로 결과가 메모리에 저장됩니다. "
            "개발 전/중/후 단계 지정과 보고서 출력은 [보고서 출력] 탭에서 합니다."
        )
        info.setWordWrap(True)
        info.setStyleSheet("color: #6b7280; font-size: 12px; border: none;")
        v.addWidget(info)

        self._memory_list_layout = QVBoxLayout()
        self._memory_list_layout.setSpacing(4)
        v.addLayout(self._memory_list_layout)

        target.addWidget(card)
        self._refresh_memory_list_ui()

    def _setup_report_tab(self):
        """'보고서 출력' 탭 신설(창 전환). CN값 계산 탭의 출력 위젯을 이 탭으로 이동(reparent).

        구성: 출력 설정(결과 저장 폴더 + 출력 포맷 + HWP 템플릿) + 3단계 비교 미리보기/사유 +
        결과 내보내기. 단계는 보고서 탭 드롭다운으로 메모리(self._memory_pool)에서 선택한다.
        """
        self._staged_report = None

        tab = QWidget()
        tab.setStyleSheet("background-color: #f9fafb;")
        outer = QVBoxLayout(tab)
        outer.setSpacing(0)
        outer.setContentsMargins(0, 0, 0, 0)

        content = QWidget()
        rlay = QVBoxLayout(content)
        rlay.setSpacing(12)
        rlay.setContentsMargins(16, 16, 16, 16)
        self._report_layout = rlay

        # 1) 출력 설정 카드
        out_card = QFrame()
        out_card.setObjectName("reportOutCard")
        out_card.setStyleSheet(
            "QFrame#reportOutCard { background-color: white; border: 1px solid #e5e7eb;"
            "  border-radius: 8px; }"
        )
        ov = QVBoxLayout(out_card)
        ov.setSpacing(10)
        ov.setContentsMargins(16, 14, 16, 14)
        ot = QLabel("출력 설정")
        ot.setStyleSheet("font-size: 14px; font-weight: bold; color: #374151; border: none;")
        ov.addWidget(ot)

        # 결과 저장 폴더 — .ui 위젯을 이 탭으로 이동
        dir_row = QHBoxLayout()
        dir_row.setSpacing(8)
        self.lblOutputDir.setMinimumWidth(110)
        dir_row.addWidget(self.lblOutputDir)
        dir_row.addWidget(self.leOutputDir)
        dir_row.addWidget(self.btnOutputDir)
        ov.addLayout(dir_row)

        # 출력 포맷
        fmt_row = QHBoxLayout()
        fmt_row.setSpacing(8)
        flbl = QLabel("출력 포맷")
        flbl.setStyleSheet("color: #6b7280; font-size: 13px; border: none;")
        flbl.setMinimumWidth(110)
        fmt_row.addWidget(flbl)
        self.chkExportExcel = QCheckBox("Excel (.xlsx)")
        self.chkExportExcel.setChecked(True)
        self.chkExportHwp = QCheckBox("한글 (.hwpx)")
        self.chkExportHwp.setChecked(False)
        fmt_row.addWidget(self.chkExportExcel)
        fmt_row.addWidget(self.chkExportHwp)
        fmt_row.addStretch()
        ov.addLayout(fmt_row)

        # HWP 템플릿은 내장본(cn_report.hwpx) 고정 사용 — 경로 입력 불필요
        hint = QLabel("※ 한글 보고서는 내장 템플릿(cn_report.hwpx)으로 출력됩니다.")
        hint.setStyleSheet("color: #9ca3af; font-size: 11px; border: none;")
        ov.addWidget(hint)
        rlay.addWidget(out_card)

        # CN값 계산 탭에 남은 입력 카드 제목 정리(이제 레이어 선택만 남음)
        if hasattr(self, 'lblRecalcInputTitle'):
            self.lblRecalcInputTitle.setText("CN값_input 레이어")

        # 2) 3단계 비교(미리보기/사유)
        self._setup_staged_report_section(rlay)

        # 3) 보고서 출력 버튼(신규) — 기존 .ui 버튼은 숨김(시그널은 동일 _export_results)
        self.btnExportResult1.setVisible(False)
        exp_row = QHBoxLayout()
        exp_row.setSpacing(8)
        exp_row.addStretch()
        self.btnReportExport = QPushButton("보고서 출력")
        self.btnReportExport.setMinimumHeight(38)
        self.btnReportExport.setMinimumWidth(140)
        self.btnReportExport.setStyleSheet(
            "QPushButton { background-color: #1f2937; color: white; border: none;"
            "  border-radius: 6px; padding: 8px 24px; font-weight: 700; }"
            "QPushButton:hover { background-color: #374151; }"
        )
        self.btnReportExport.clicked.connect(self._export_results)
        exp_row.addWidget(self.btnReportExport)
        rlay.addLayout(exp_row)
        rlay.addStretch()

        # 스크롤 래핑
        scroll = QScrollArea()
        scroll.setWidget(content)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setStyleSheet("QScrollArea { border: none; background: transparent; }")
        outer.addWidget(scroll)

        self.tabWidget.addTab(tab, "보고서 출력")

    def _setup_staged_report_section(self, parent_layout):
        """보고서 탭: 3단계 비교 토글 + 개발 전/중/후 드롭다운(메모리 선택) + 미리보기/사유 표."""
        self._stage_combos = {}
        card = QFrame()
        card.setObjectName("stagedCard")
        card.setStyleSheet(
            "QFrame#stagedCard { background-color: white; border: 1px solid #e5e7eb;"
            "  border-radius: 8px; }"
        )
        v = QVBoxLayout(card)
        v.setSpacing(10)
        v.setContentsMargins(16, 14, 16, 14)

        self.chkStaged = QCheckBox("비교 검토 기능")
        self.chkStaged.setStyleSheet(
            "font-size: 14px; font-weight: bold; color: #374151; border: none;")
        self.chkStaged.setChecked(False)
        v.addWidget(self.chkStaged)

        info = QLabel(
            "[CN값 계산] 탭에서 저장한 개발 전/중/후 단계로 증감 비교표(표4-17)와 단계별 산정결과표"
            "(표4-19)를 한글 보고서로 출력합니다. 미리보기로 표를 확인하고 적정성 사유를 입력하세요. "
            "(체크 해제 시 단일 결과로 출력)"
        )
        info.setWordWrap(True)
        info.setStyleSheet("color: #6b7280; font-size: 12px; border: none;")
        v.addWidget(info)

        self._staged_body = QWidget()
        body = QVBoxLayout(self._staged_body)
        body.setSpacing(8)
        body.setContentsMargins(0, 0, 0, 0)

        # 개발 전/중/후 = 저장된 메모리에서 선택(드롭다운)
        stage_tint = {STAGE_PRE: "#ecfdf5", STAGE_DURING: "#fffbeb", STAGE_POST: "#fef2f2"}
        for stage in DEFAULT_STAGE_ORDER:
            srow = QHBoxLayout()
            srow.setSpacing(8)
            slbl = QLabel(stage)
            slbl.setStyleSheet("color: #374151; font-size: 13px; font-weight: 600; border: none;")
            slbl.setMinimumWidth(70)
            srow.addWidget(slbl)
            cmb = QComboBox()
            cmb.addItem("(미지정)", "")
            cmb.setStyleSheet(
                "QComboBox { border: 1px solid #d1d5db; border-radius: 4px;"
                f"  padding: 4px 8px; background-color: {stage_tint.get(stage, 'white')}; color: #374151; }}"
                "QComboBox:hover { border-color: #9ca3af; }")
            srow.addWidget(cmb, 1)
            self._stage_combos[stage] = cmb
            body.addLayout(srow)

        btn_row = QHBoxLayout()
        btn_row.setSpacing(8)
        btn_row.addStretch()
        self.btnStagedPreview = QPushButton("비교표 미리보기 / 사유 입력")
        self.btnStagedPreview.setStyleSheet(
            "QPushButton { border: 1px solid #374151; color: #374151; border-radius: 6px;"
            "  padding: 5px 12px; background: white; font-weight: 600; }"
            "QPushButton:hover { background-color: #f3f4f6; }"
        )
        btn_row.addWidget(self.btnStagedPreview)
        body.addLayout(btn_row)

        self.tblStaged = QTableWidget(0, 8)
        self.tblStaged.setHorizontalHeaderLabels([
            "소유역", "개발 전 CN", "개발 중 CN", "증감(중)",
            "개발 중 적정성 사유", "개발 후 CN", "증감(후)", "개발 후 적정성 사유",
        ])
        hh = self.tblStaged.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        for c in (1, 2, 3, 5, 6):
            hh.setSectionResizeMode(c, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(4, QHeaderView.Stretch)
        hh.setSectionResizeMode(7, QHeaderView.Stretch)
        self.tblStaged.verticalHeader().setDefaultSectionSize(30)
        self.tblStaged.verticalHeader().setVisible(False)
        self.tblStaged.setMinimumHeight(160)
        body.addWidget(self.tblStaged)

        v.addWidget(self._staged_body)
        parent_layout.addWidget(card)

        self._staged_set_body_enabled(False)
        self.chkStaged.toggled.connect(self._on_staged_toggled)
        self.btnStagedPreview.clicked.connect(self._staged_preview)

    def _staged_set_body_enabled(self, on: bool):
        if getattr(self, '_staged_body', None) is not None:
            self._staged_body.setEnabled(on)

    def _on_staged_toggled(self, checked: bool):
        self._staged_set_body_enabled(checked)
        if checked:
            self._refresh_stage_combos()
            # 3단계 비교 보고서는 한글(.hwpx) 출력이 핵심 → 자동 체크
            if getattr(self, 'chkExportHwp', None) is not None and not self.chkExportHwp.isChecked():
                self.chkExportHwp.setChecked(True)

    def _save_to_memory(self, name: str, layer):
        """레이어의 CN 계산 결과를 '이름'으로 메모리에 저장(스냅샷). 같은 이름은 덮어쓴다.

        유역합성 그룹이 정의돼 있으면 합성 결과(composite)도 함께 스냅샷에 담아
        Excel/한글 보고서(표4-19)에 유역합성 산정결과가 누락되지 않도록 한다.
        """
        try:
            r1, r2, _null = calculate_results(layer)
            grouped_r1, grouped_r2 = None, None
            groups = self._get_watershed_groups()
            if groups:
                try:
                    grouped_r1, grouped_r2 = calculate_grouped_results(layer, groups)
                    self._recalc_log(f"   ✔ 유역합성 {len(grouped_r1 or [])}개 그룹 포함")
                except Exception as ge:
                    logger.exception("유역합성 계산 오류(메모리 저장)")
                    self._recalc_log(f"   [경고] 유역합성 계산 실패(개별 결과만 저장): {ge}")
                    grouped_r1, grouped_r2 = None, None
            ares = build_analysis_result(
                r1, r2, meta=self._build_staged_meta(name),
                grouped_result1=grouped_r1, grouped_result2=grouped_r2)
        except Exception as e:
            logger.exception("메모리 저장 계산 오류")
            self._recalc_log(f"   [경고] '{name}' 메모리 저장 실패: {e}")
            return
        cns = [s.amc3_cn for s in ares.summary_rows if s.amc3_cn]
        mean_cn = (sum(cns) / len(cns)) if cns else 0.0
        from datetime import datetime
        self._memory_pool[name] = {
            'layer_name': name, 'layer_id': layer.id(), 'result': ares,
            'n_ws': len(ares.summary_rows), 'mean_cn': mean_cn,
            'at': datetime.now().strftime("%H:%M:%S"),
        }
        self._refresh_memory_list_ui()
        self._refresh_stage_combos()
        self._recalc_log(
            f"   ✔ 메모리 저장: '{name}' (소유역 {len(ares.summary_rows)}개 · 평균 CN {mean_cn:.1f})")

    def _delete_memory(self, name: str):
        if name in getattr(self, '_memory_pool', {}):
            del self._memory_pool[name]
            self._refresh_memory_list_ui()
            self._refresh_stage_combos()
            self._recalc_log(f"   메모리 삭제: '{name}'")

    def _clear_layout(self, lay):
        while lay.count():
            item = lay.takeAt(0)
            w = item.widget()
            if w is not None:
                w.setParent(None)
            elif item.layout() is not None:
                self._clear_layout(item.layout())

    def _refresh_memory_list_ui(self):
        """CN값 계산 탭의 '저장된 CN 메모리' 목록 갱신."""
        lay = getattr(self, '_memory_list_layout', None)
        if lay is None:
            return
        self._clear_layout(lay)
        pool = getattr(self, '_memory_pool', {})
        if not pool:
            empty = QLabel("(저장된 메모리 없음 — 레이어 이름 입력 후 CN값 계산을 실행하세요)")
            empty.setStyleSheet("color: #9ca3af; font-size: 12px; border: none;")
            lay.addWidget(empty)
            return
        for name, slot in pool.items():
            row = QHBoxLayout()
            row.setSpacing(8)
            lbl = QLabel(f"• {name} · 소유역 {slot['n_ws']}개 · 평균 CN {slot['mean_cn']:.1f} · {slot['at']}")
            lbl.setStyleSheet("color: #166534; font-size: 12px; font-weight: 600; border: none;")
            row.addWidget(lbl, 1)
            btn = QPushButton("지우기")
            btn.setStyleSheet(
                "QPushButton { border: 1px solid #d1d5db; color: #6b7280; border-radius: 6px;"
                "  padding: 2px 10px; background: white; }"
                "QPushButton:hover { background-color: #f3f4f6; }")
            btn.clicked.connect(lambda _checked=False, n=name: self._delete_memory(n))
            row.addWidget(btn)
            lay.addLayout(row)

    def _refresh_stage_combos(self):
        """보고서 탭 개발 전/중/후 드롭다운을 메모리 목록으로 갱신(이전 선택 보존)."""
        combos = getattr(self, '_stage_combos', None)
        if not combos:
            return
        names = list(getattr(self, '_memory_pool', {}).keys())
        for cmb in combos.values():
            prev = cmb.currentData()
            cmb.clear()
            cmb.addItem("(미지정)", "")
            for n in names:
                cmb.addItem(n, n)
            i = cmb.findData(prev) if prev else 0
            cmb.setCurrentIndex(i if i >= 0 else 0)

    def _build_staged_meta(self, stage: str = "") -> ProjectMeta:
        folder = self.leOutputDir.text().strip()
        return ProjectMeta(
            project_name=os.path.basename(folder) if folder else "",
            land_cover_level=self._get_selected_level_key(),
            data_source=self._get_selected_data_source(),
            development_stage=stage or "개발 전/중/후",
        )

    def _collect_staged_reasons(self) -> dict:
        """미리보기 표 → {소유역명: (개발중 사유, 개발후 사유)} (사용자 입력 보존용)."""
        out = {}
        tbl = getattr(self, 'tblStaged', None)
        if tbl is None:
            return out
        for r in range(tbl.rowCount()):
            ws_item = tbl.item(r, 0)
            if ws_item is None or not ws_item.text().strip():
                continue
            rd = tbl.item(r, 4)
            rp = tbl.item(r, 7)
            out[ws_item.text().strip()] = (
                rd.text().strip() if rd else "",
                rp.text().strip() if rp else "",
            )
        return out

    def _populate_staged_table(self, report) -> None:
        tbl = self.tblStaged
        rows = report.cn_delta_rows
        tbl.setRowCount(len(rows))

        def _cn(v):
            return "" if v is None else f"{v:.2f}"

        def _inc(v):
            if v is None:
                return "-"
            if v > 0:
                return f"증) {v:.2f}"
            if v < 0:
                return f"감) {abs(v):.2f}"
            return "-"

        ro_cols = {0, 1, 2, 3, 5, 6}      # 읽기전용(편집 가능 = 사유 4·7)
        for r, d in enumerate(rows):
            vals = [
                d.watershed, _cn(d.cn_pre), _cn(d.cn_during), _inc(d.delta_during),
                d.reason_during or "", _cn(d.cn_post), _inc(d.delta_post), d.reason_post or "",
            ]
            for c, text in enumerate(vals):
                item = QTableWidgetItem(text)
                if c in ro_cols:
                    item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                    if c != 0:
                        item.setTextAlignment(Qt.AlignCenter)
                tbl.setItem(r, c, item)

    def _refresh_composite_from_groups(self, present, sel, pool):
        """내보내기 시점의 유역합성 그룹 정의로 각 단계 스냅샷의 합성(composite) 결과를 갱신.

        합성 산정결과는 스냅샷에 고정돼 있어, CN계산 *이후* 그룹을 정의/변경하면 3단계
        보고서(Excel·한글)에 유역합성이 빠진다. 스냅샷이 가리키는 레이어로부터 현재 그룹으로
        합성 블록을 재계산해 주입(단일단계 경로와 동일하게 내보내기 시점 계산). 레이어가
        사라졌거나 그룹이 없으면 기존 스냅샷 값을 유지한다(graceful).
        """
        groups = self._get_watershed_groups()
        if not groups:
            return
        from qgis.core import QgsProject
        for s in present:
            slot = pool[sel[s]]
            layer = QgsProject.instance().mapLayer(slot.get('layer_id') or "")
            if layer is None:
                continue
            try:
                gr1, gr2 = calculate_grouped_results(layer, groups)
                tmp = build_analysis_result([], [], grouped_result1=gr1, grouped_result2=gr2)
                ares = slot['result']
                ares.composite_detail = tmp.composite_detail
                ares.composite_summary = tmp.composite_summary
                self._recalc_log(f"  '{s}' 유역합성 {len(gr1 or [])}개 그룹 반영")
            except Exception as e:
                logger.exception("유역합성 재계산 오류(내보내기)")
                self._recalc_log(f"  [경고] '{s}' 유역합성 재계산 실패(기존 값 유지): {e}")

    def _staged_build_report(self, *, announce: bool = True):
        """메모리에 저장된 단계 슬롯(스냅샷)으로 StagedReport 조립. 실패 시 None.

        계산은 '단계로 저장' 시점에 끝나 있어 여기선 재계산하지 않는다(스냅샷 사용).
        입력된 적정성 사유는 소유역명 매칭으로 보존한다(cn_delta_rows 소유역명은 유일).
        """
        pool = getattr(self, '_memory_pool', {})
        sel = {}
        for stage, cmb in (getattr(self, '_stage_combos', None) or {}).items():
            nm = cmb.currentData()
            if nm and nm in pool:
                sel[stage] = nm
        present = [s for s in DEFAULT_STAGE_ORDER if s in sel]
        if len(present) < 2:
            if announce:
                QMessageBox.warning(
                    self, "3단계 비교",
                    "비교하려면 개발 전/중/후 중 2개 이상에 저장된 메모리를 지정하세요.")
            return None
        if STAGE_PRE not in sel:
            if announce:
                QMessageBox.warning(
                    self, "3단계 비교",
                    "증감(②-①, ③-①)은 개발 전(①) 기준입니다. '개발 전'을 지정하세요.")
            return None

        prev_reasons = self._collect_staged_reasons()
        stage_results = {s: pool[sel[s]]['result'] for s in present}
        # 내보내기 시점의 유역합성 그룹으로 합성 결과 최신화(CN계산 후 그룹을 정의/변경한 경우 누락 방지)
        self._refresh_composite_from_groups(present, sel, pool)
        report = assemble_staged_report(stage_results, meta=self._build_staged_meta())
        for row in report.cn_delta_rows:        # 사유 재주입(이름 키 — cn_delta_rows 소유역명 유일)
            keep = prev_reasons.get(row.watershed)
            if keep:
                row.reason_during, row.reason_post = keep

        cur_ws = {r.watershed for r in report.cn_delta_rows}
        lost = sorted({ws for ws, (rd, rp) in prev_reasons.items() if rd or rp} - cur_ws)
        if lost:
            self._recalc_log(f"  [경고] 단계 변경으로 사유 보존 실패: {', '.join(lost)}")

        self._staged_report = report
        self._populate_staged_table(report)
        return report

    def _staged_preview(self):
        report = self._staged_build_report(announce=True)
        if report is not None:
            self._recalc_log(
                f"3단계 비교표 미리보기: 소유역 {len(report.cn_delta_rows)}개 "
                f"(단계 {len(report.stage_order)}개). 적정성 사유 셀에 입력 후 결과 내보내기.")

    def _export_staged(self):
        """3단계 비교 보고서 내보내기 — 한글(표4-17/18/19) + 단계별 Excel."""
        want_excel = getattr(self, 'chkExportExcel', None) is None or self.chkExportExcel.isChecked()
        want_hwp = getattr(self, 'chkExportHwp', None) is not None and self.chkExportHwp.isChecked()
        if not (want_excel or want_hwp):
            QMessageBox.warning(self, "입력 오류", "Excel 또는 한글 중 하나 이상 선택해야 합니다.")
            return
        try:
            folder = self._get_output_dir()
        except ValueError as e:
            QMessageBox.warning(self, "입력 오류", str(e))
            return

        self._recalc_log("▶ 3단계 비교 보고서 내보내기 시작...")
        # 저장된 단계 슬롯(스냅샷)으로 보고서 생성(입력된 사유 보존)
        report = self._staged_build_report(announce=True)
        if report is None:
            return

        summary_lines: list[str] = []

        # 한글(.hwpx) — 표4-17 증감 + 표4-18 기준 + 표4-19 단계 결과
        if want_hwp:
            hwp_path = os.path.join(folder, "result.hwpx")
            template = DEFAULT_HWP_TEMPLATE        # 내장 템플릿 고정 사용
            try:
                from .core.hwpx_writer import render_staged_report
                self._recalc_log(f"  3단계 HWPX 저장 중... ({hwp_path})")
                render_staged_report(report, template, hwp_path)
                self._recalc_log("  ✔ 3단계 한글 보고서 저장 완료")
                summary_lines.append(f"HWP(3단계): {hwp_path}")
            except Exception as e:
                logger.exception("3단계 HWP 내보내기 오류")
                self._recalc_log(f"  [경고] 3단계 HWP 저장 실패: {e}")
                summary_lines.append(f"HWP(3단계): 실패 — {e}")

        # Excel — 하나의 파일에 단계별 시트(개발 전/중/후)
        if want_excel:
            xpath = os.path.join(folder, "result.xlsx")
            try:
                export_excel_staged(report.ordered_stages(), xpath)
                self._recalc_log(f"  ✔ Excel 저장(단계별 시트): {os.path.basename(xpath)}")
                summary_lines.append(f"Excel(3단계): {xpath}")
            except Exception as e:
                logger.exception("3단계 Excel 내보내기 오류")
                self._recalc_log(f"  [경고] Excel 저장 실패: {e}")
                summary_lines.append(f"Excel(3단계): 실패 — {e}")

        if report.stage_order:        # 어떤 단계가 실제 포함됐는지 명시(조용한 누락 방지)
            summary_lines.insert(0, f"포함 단계: {' / '.join(report.stage_order)}")
        QMessageBox.information(self, "저장 결과",
                               "\n".join(summary_lines) or "출력된 파일이 없습니다.")

    def _enhance_recalc_tab(self):
        """CN값 계산 탭 상단에 'CN값 계산' 카드를 동적으로 추가."""
        recalc_tab = self.tabWidget.widget(TAB_RECALC)
        outer_layout = recalc_tab.layout()
        if outer_layout is None:
            return

        card = QFrame()
        card.setObjectName("applyCard")
        card.setStyleSheet(
            "QFrame#applyCard {"
            "  background-color: white; border: 1px solid #e5e7eb; border-radius: 8px;"
            "}"
        )
        card_layout = QVBoxLayout(card)
        card_layout.setSpacing(10)
        card_layout.setContentsMargins(16, 14, 16, 14)

        # 카드 헤더
        card_title = QLabel("CN값 계산")
        card_title.setStyleSheet(
            "font-size: 14px; font-weight: bold; color: #374151; border: none;"
        )
        card_layout.addWidget(card_title)

        # 설명
        lbl = QLabel(
            "[레이어 불러오기] 탭에서 불러온 교차 레이어를 기반으로 토지이용 재분류 매핑과 "
            "CN값을 적용하여 CN값_input 레이어를 생성합니다."
        )
        lbl.setWordWrap(True)
        lbl.setStyleSheet("color: #6b7280; font-size: 12px; border: none;")
        card_layout.addWidget(lbl)

        # 프로그레스 바
        self.progressBarCalc = QProgressBar()
        self.progressBarCalc.setValue(0)
        self.progressBarCalc.setTextVisible(True)
        self.progressBarCalc.setFormat("%p%  %v/%m")
        self.progressBarCalc.setFixedHeight(20)
        self.progressBarCalc.setStyleSheet(
            "QProgressBar {"
            "  border: 1px solid #e5e7eb; border-radius: 4px;"
            "  background-color: #f3f4f6; text-align: center;"
            "  font-size: 11px; color: #374151;"
            "}"
            "QProgressBar::chunk {"
            "  background-color: #1f2937; border-radius: 3px;"
            "}"
        )
        # 숨김 상태에서도 자리(높이)를 유지 → 계산 중 표시될 때 레이아웃이 밀리며
        # 위젯이 겹쳐 그려지는(씹힘) 현상 방지.
        _sp = self.progressBarCalc.sizePolicy()
        _sp.setRetainSizeWhenHidden(True)
        self.progressBarCalc.setSizePolicy(_sp)
        self.progressBarCalc.setVisible(False)
        card_layout.addWidget(self.progressBarCalc)

        # 레이어 이름 입력(메모리 저장 키로 사용)
        name_row = QHBoxLayout()
        name_row.setSpacing(8)
        name_lbl = QLabel("레이어 이름")
        name_lbl.setStyleSheet("color: #6b7280; font-size: 13px; border: none;")
        name_lbl.setMinimumWidth(80)
        name_row.addWidget(name_lbl)
        self.leLayerName = QLineEdit()
        self.leLayerName.setPlaceholderText("예: 개발전_CN  (비우면 CN값_input)")
        name_row.addWidget(self.leLayerName)
        card_layout.addLayout(name_row)

        # 버튼 행
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        self.btnApplyCn = QPushButton("CN값 계산 실행")
        self.btnApplyCn.setMinimumHeight(34)
        self.btnApplyCn.setStyleSheet(
            "QPushButton {"
            "  background-color: #1f2937; color: white;"
            "  border: none; border-radius: 6px;"
            "  padding: 7px 24px; font-weight: 600;"
            "}"
            "QPushButton:hover { background-color: #374151; }"
            "QPushButton:disabled { background-color: #9ca3af; }"
        )
        btn_row.addWidget(self.btnApplyCn)
        card_layout.addLayout(btn_row)

        # 유역합성 카드를 먼저 삽입 (토글 접힘 상태)
        self._setup_watershed_group_card(outer_layout)
        # CN값 계산 카드를 유역합성 아래에 삽입
        self._applyCard = card      # 계산 중 강제 repaint 대상(잔상/씹힘 방지)
        outer_layout.insertWidget(1, card)

        # Tab 3 전체를 QScrollArea로 감싸기 (창 축소 시 찌그러짐 방지)
        self._wrap_tab_in_scroll(recalc_tab)

    def _wrap_tab_in_scroll(self, tab_widget):
        """탭 내부 위젯들을 QScrollArea로 감싸서 창 축소 시 스크롤 가능하게 한다."""
        layout = tab_widget.layout()
        margins = layout.contentsMargins()
        spacing = layout.spacing()

        container = QWidget()
        container_layout = QVBoxLayout(container)
        container_layout.setSpacing(spacing)
        container_layout.setContentsMargins(margins)

        # 기존 아이템을 컨테이너로 이동 (spacer 제거)
        while layout.count():
            item = layout.takeAt(0)
            if item.widget():
                container_layout.addWidget(item.widget())
            elif item.layout():
                container_layout.addLayout(item.layout())
            # spacerItem은 건너뜀 (불필요한 여백 제거)

        # CN값 계산 탭 컨텐츠 레이아웃 보관(메모리 관리 카드 추가용)
        self._recalc_content_layout = container_layout

        # 원래 레이아웃을 스크롤 전용으로 변경
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        scroll = QScrollArea()
        scroll.setWidget(container)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setStyleSheet("QScrollArea { border: none; background: transparent; }")

        layout.addWidget(scroll)

    def _setup_watershed_group_card(self, recalc_layout):
        """Tab 3에 유역합성 설정 카드를 동적으로 추가 (체크박스 토글, 기본 접힘)."""
        from qgis.PyQt.QtWidgets import QCheckBox

        card = QFrame()
        card.setObjectName("watershedGroupCard")
        card.setStyleSheet(
            "QFrame#watershedGroupCard {"
            "  background-color: white; border: 1px solid #e5e7eb; border-radius: 8px;"
            "}"
        )
        card_layout = QVBoxLayout(card)
        card_layout.setSpacing(10)
        card_layout.setContentsMargins(16, 14, 16, 14)

        # 카드 헤더 — 체크박스로 토글
        header_row = QHBoxLayout()
        self.chkWsGroup = QCheckBox("유역합성 사용")
        self.chkWsGroup.setStyleSheet(
            "QCheckBox { font-size: 14px; font-weight: bold; color: #374151; border: none; }"
        )
        self.chkWsGroup.setChecked(False)
        header_row.addWidget(self.chkWsGroup)
        header_row.addStretch()

        self.btnWsGroupAddRow = QPushButton("+ 행 추가")
        self.btnWsGroupDeleteRow = QPushButton("- 행 삭제")
        header_row.addWidget(self.btnWsGroupAddRow)
        header_row.addWidget(self.btnWsGroupDeleteRow)
        card_layout.addLayout(header_row)

        # 접힘 가능한 컨텐츠 컨테이너
        self._wsGroupContent = QWidget()
        content_layout = QVBoxLayout(self._wsGroupContent)
        content_layout.setSpacing(10)
        content_layout.setContentsMargins(0, 0, 0, 0)

        # 설명
        desc = QLabel(
            "소유역을 그룹화하여 합성 CN값을 계산합니다. "
            "그룹명을 입력하고, 해당 그룹에 포함될 소유역을 선택하세요. (최대 20개)"
        )
        desc.setWordWrap(True)
        desc.setStyleSheet("color: #6b7280; font-size: 12px; border: none;")
        content_layout.addWidget(desc)

        # 테이블 (그룹명 + 소유역1~20)
        self._ws_max_members = 20
        self.tblWsGroups = QTableWidget(0, 1 + self._ws_max_members)
        headers = ['그룹명'] + [f'소유역{i}' for i in range(1, self._ws_max_members + 1)]
        self.tblWsGroups.setHorizontalHeaderLabels(headers)
        self.tblWsGroups.horizontalHeader().setSectionResizeMode(0, QHeaderView.Interactive)
        self.tblWsGroups.setColumnWidth(0, 100)
        for c in range(1, 1 + self._ws_max_members):
            self.tblWsGroups.horizontalHeader().setSectionResizeMode(c, QHeaderView.Interactive)
            self.tblWsGroups.setColumnWidth(c, 90)
        self.tblWsGroups.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tblWsGroups.verticalHeader().setDefaultSectionSize(32)
        self.tblWsGroups.verticalHeader().setVisible(False)
        self.tblWsGroups.setFixedHeight(140)
        self.tblWsGroups.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        content_layout.addWidget(self.tblWsGroups)

        # 버튼 행
        btn_row = QHBoxLayout()
        btn_row.setSpacing(8)
        btn_row.addStretch()

        self.btnWsGroupLoad = QPushButton("불러오기")
        self.btnWsGroupSave = QPushButton("저장")
        self.btnWsGroupSave.setStyleSheet(
            "QPushButton { background-color: #1f2937; color: white;"
            "  border: none; border-radius: 6px; padding: 6px 20px; font-weight: 600; }"
            "QPushButton:hover { background-color: #374151; }"
        )
        btn_row.addWidget(self.btnWsGroupLoad)
        btn_row.addWidget(self.btnWsGroupSave)
        content_layout.addLayout(btn_row)

        card_layout.addWidget(self._wsGroupContent)

        # 컨텐츠 높이만 고정 (카드는 sizeHint로 자동 축소/확장 → 토글 시 260 이내)
        self._wsGroupContent.setFixedHeight(210)
        card.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)

        # 기본 접힘 상태 — 헤더만 표시
        self._wsGroupContent.setVisible(False)
        self.btnWsGroupAddRow.setVisible(False)
        self.btnWsGroupDeleteRow.setVisible(False)

        self._wsGroupCard = card

        # 체크박스 토글 연결
        self.chkWsGroup.toggled.connect(self._toggle_ws_group)

        # CN값 계산 카드보다 먼저 삽입 (position 0)
        recalc_layout.insertWidget(0, card)

        # Connect signals
        self.btnWsGroupAddRow.clicked.connect(self._ws_group_add_row)
        self.btnWsGroupDeleteRow.clicked.connect(self._ws_group_delete_row)
        self.btnWsGroupSave.clicked.connect(self._ws_group_save)
        self.btnWsGroupLoad.clicked.connect(self._ws_group_load)

    def _toggle_ws_group(self, checked):
        """유역합성 체크박스 토글 — 컨텐츠 표시/숨김. 카드는 sizeHint로 자동 조절."""
        self._wsGroupContent.setVisible(checked)
        self.btnWsGroupAddRow.setVisible(checked)
        self.btnWsGroupDeleteRow.setVisible(checked)
        self._wsGroupCard.adjustSize()
        self._wsGroupCard.updateGeometry()

    def _get_watershed_names(self) -> list:
        """소유역명 고유값 목록을 반환. 입력 레이어 → CN값_input 폴백."""
        _INVALID = {'', 'null', 'none', 'nan'}

        def _valid_name(val):
            if val is None:
                return None
            try:
                from qgis.PyQt.QtCore import QVariant
                if isinstance(val, QVariant) and val.isNull():
                    return None
            except Exception:
                pass
            s = str(val).strip()
            return s if s and s.lower() not in _INVALID else None

        # 1) 입력 레이어에서 조회
        if hasattr(self, 'input_layer') and self.input_layer is not None and self._last_name_field:
            try:
                names = sorted({
                    n for f in self.input_layer.getFeatures()
                    if (n := _valid_name(f[self._last_name_field]))
                })
                if names:
                    return names
            except Exception as e:
                logger.debug(f"입력 레이어에서 소유역명 조회 실패: {e}")

        # 2) CN값_input 레이어에서 폴백 조회
        for lyr in QgsProject.instance().mapLayers().values():
            try:
                if lyr.type() == QgsMapLayerType.VectorLayer and lyr.name() == "CN값_input":
                    names = sorted({
                        n for f in lyr.getFeatures()
                        if (n := _valid_name(f['소유역명']))
                    })
                    if names:
                        return names
            except Exception as e:
                logger.debug(f"CN값_input 레이어에서 소유역명 조회 실패: {e}")

        return []

    def _ws_create_combo(self, ws_names: list, selected: str = '') -> 'QComboBox':
        """소유역 선택용 콤보박스 생성."""
        from qgis.PyQt.QtWidgets import QComboBox
        cmb = QComboBox()
        cmb.setEditable(True)
        cmb.addItem('')  # 빈 항목 (선택 안 함)
        cmb.addItems(ws_names)
        if selected:
            idx = cmb.findText(selected)
            if idx >= 0:
                cmb.setCurrentIndex(idx)
            else:
                cmb.setCurrentText(selected)
        cmb.setStyleSheet(
            "QComboBox { border: none; padding: 2px 4px; background: transparent; }"
        )
        return cmb

    def _ws_group_add_row(self):
        try:
            ws_names = self._get_watershed_names()
        except Exception as e:
            logger.exception("소유역명 목록 조회 오류")
            ws_names = []

        if not ws_names:
            reply = QMessageBox.question(
                self, "소유역 데이터 없음",
                "소유역 목록을 불러올 수 없습니다.\n"
                "[레이어 불러오기] 탭에서 먼저 실행하거나,\n"
                "CN값 계산을 먼저 수행하세요.\n\n"
                "소유역명을 직접 입력하시겠습니까?",
                QMessageBox.Yes | QMessageBox.No
            )
            if reply != QMessageBox.Yes:
                return
        tbl = self.tblWsGroups
        row = tbl.rowCount()
        tbl.insertRow(row)
        # 그룹명은 텍스트 입력
        tbl.setItem(row, 0, QTableWidgetItem(''))
        # 소유역 열은 콤보박스
        for c in range(1, tbl.columnCount()):
            cmb = self._ws_create_combo(ws_names)
            tbl.setCellWidget(row, c, cmb)
        tbl.scrollToBottom()
        tbl.setCurrentCell(row, 0)

    def _ws_group_delete_row(self):
        tbl = self.tblWsGroups
        row = tbl.currentRow()
        if row < 0:
            QMessageBox.information(self, "행 삭제", "삭제할 행을 먼저 선택하세요.")
            return
        tbl.removeRow(row)

    def _ws_group_save(self):
        """유역합성 테이블 → JSON 저장."""
        groups = self._get_watershed_groups()
        try:
            save_groups(groups)
            QMessageBox.information(
                self, "저장 완료",
                f"유역합성 그룹이 저장되었습니다.\n그룹 수: {len(groups)}개"
            )
        except Exception as e:
            QMessageBox.critical(self, "저장 오류", str(e))

    def _ws_group_load(self):
        """저장된 유역합성 그룹을 테이블에 로드."""
        groups = load_groups()
        if not groups:
            QMessageBox.information(self, "불러오기", "저장된 유역합성 그룹이 없습니다.")
            return
        try:
            ws_names = self._get_watershed_names()
        except Exception as e:
            logger.exception("소유역명 목록 조회 오류 (불러오기)")
            ws_names = []
        tbl = self.tblWsGroups
        tbl.setRowCount(0)
        for group_name, members in groups.items():
            row = tbl.rowCount()
            tbl.insertRow(row)
            tbl.setItem(row, 0, QTableWidgetItem(group_name))
            for i in range(self._ws_max_members):
                selected = members[i] if i < len(members) else ''
                cmb = self._ws_create_combo(ws_names, selected)
                tbl.setCellWidget(row, i + 1, cmb)
        QMessageBox.information(
            self, "불러오기 완료",
            f"유역합성 그룹 {len(groups)}개를 불러왔습니다."
        )

    def _get_watershed_groups(self) -> dict:
        """유역합성 테이블에서 그룹 데이터 추출 (콤보박스에서 값 읽기)."""
        tbl = self.tblWsGroups
        groups = {}
        for r in range(tbl.rowCount()):
            name_item = tbl.item(r, 0)
            group_name = name_item.text().strip() if name_item else ''
            if not group_name:
                continue
            members = []
            for c in range(1, tbl.columnCount()):
                widget = tbl.cellWidget(r, c)
                if widget:
                    val = widget.currentText().strip()
                else:
                    item = tbl.item(r, c)
                    val = item.text().strip() if item else ''
                if val:
                    members.append(val)
            if members:
                groups[group_name] = members
        return groups

    def _apply_cn_calc(self):
        """교차 레이어에 토지이용 매핑·CN값을 적용하여 CN값_input 레이어를 최초 생성."""
        if self._final_intersect_layer is None:
            QMessageBox.warning(
                self, "레이어 없음",
                "먼저 [레이어 불러오기] 탭에서 실행하세요."
            )
            return

        self._recalc_log("▶ CN값 계산 중...")
        self.progressBarCalc.setVisible(True)
        self.progressBarCalc.setMaximum(5)
        self.progressBarCalc.setValue(0)
        # 자리 확보 후 즉시 클린 리페인트 — processEvents 반복 시 잔상(씹힘) 방지
        if hasattr(self, '_applyCard'):
            self._applyCard.repaint()
        self.btnApplyCn.setEnabled(False)
        from qgis.PyQt.QtWidgets import QApplication
        try:
            # ⑤ CN값_input 레이어 구성
            self.progressBarCalc.setValue(1)
            QApplication.processEvents()
            self._recalc_log("⑤ CN값_input 레이어 구성 중...")
            _, name_col = LEVEL_COLUMNS[self._last_level]
            cn_input_layer = _build_result_layer(
                self._final_intersect_layer, self._last_name_field, name_col
            )
            self._recalc_log(f"   → {cn_input_layer.featureCount()} features 생성")

            # ⑥ 토지이용 재분류 매핑 적용
            self.progressBarCalc.setValue(2)
            QApplication.processEvents()
            from .core.land_use_mapper import load_mapping, apply_mapping_to_layer
            mapping = load_mapping()
            if mapping:
                changed = apply_mapping_to_layer(cn_input_layer, mapping)
                self._recalc_log(f"⑥ 토지이용 재분류 적용: {changed}건")
            else:
                self._recalc_log("⑥ (저장된 재분류 매핑 없음)")

            # ⑦ CN값 매칭 (편집 탭에 로드된 테이블 우선, 없으면 기본 파일)
            self.progressBarCalc.setValue(3)
            QApplication.processEvents()
            self._recalc_log("⑦ CN값 매칭 중...")
            if not self._cn_table_loaded:
                self._load_cn_to_table()
            cn_table = self._get_cn_table_from_widget()
            if cn_table.empty:
                cn_table = load_cn_table()
            fail_list = apply_cn_to_layer(cn_input_layer, cn_table, self._last_level)
            if fail_list:
                self._recalc_log(f"   ⚠ CN 매칭 실패: {len(fail_list)}건")
                for wname, luse, htype in fail_list[:10]:
                    self._recalc_log(f"      - 소유역={wname}, 토지이용={luse}, 토양군={htype}")
                if len(fail_list) > 10:
                    self._recalc_log(f"      ... 외 {len(fail_list) - 10}건")
            else:
                self._recalc_log("   ✔ 모든 피처 CN값 매칭 완료")

            # 레이어 추가 — 사용자 지정 이름(메모리 저장 키)
            self.progressBarCalc.setValue(4)
            QApplication.processEvents()
            layer_name = (self.leLayerName.text().strip()
                          if hasattr(self, 'leLayerName') else "") or "CN값_input"
            cn_input_layer.setName(layer_name)
            QgsProject.instance().addMapLayer(cn_input_layer)
            self._recalc_log(f"   ✦ 레이어 추가됨: [{layer_name}]")
            self._refresh_recalc_layer_list()
            # 계산 결과를 그 이름으로 메모리에 저장(스냅샷)
            self._save_to_memory(layer_name, cn_input_layer)

            self.progressBarCalc.setValue(5)
            self._recalc_log("━" * 44)
            self._recalc_log("✔ CN값 계산 완료!")
        except Exception as e:
            logger.exception("CN값 계산 오류")
            self._recalc_log(f"[오류] {e}")
            QMessageBox.critical(self, "오류", str(e))
            self.progressBarCalc.setValue(0)
        finally:
            self.btnApplyCn.setEnabled(True)
            if hasattr(self, '_applyCard'):     # 잔여 스테일 픽셀 정리(최종 클린 프레임)
                self._applyCard.update()

    def _load_xlsx_as_layer(self, path: str, name: str, sheet: str = "Sheet1"):
        """xlsx 파일의 특정 시트를 QGIS 테이블 레이어로 프로젝트에 추가."""
        uri = f"{path}|layername={sheet}"
        layer = QgsVectorLayer(uri, name, "ogr")
        if layer.isValid():
            QgsProject.instance().addMapLayer(layer)
            self._recalc_log(f"   ✦ 레이어로 표시됨: [{name}] (시트: {sheet})")
        else:
            self._recalc_log(f"   ⚠ 레이어 로드 실패 (파일은 저장됨): {path}")

    def _warn_null_cn(self, null_cn_rows: list):
        """CN값 NULL 피처가 있을 경우 경고 다이얼로그 표시."""
        if not null_cn_rows:
            return
        lines = [f"CN값 NULL로 계산에서 제외된 피처 {len(null_cn_rows)}건:\n"]
        for ws, lu, ht in null_cn_rows[:20]:
            lines.append(f"  • 소유역={ws}, 토지이용={lu}, 토양군={ht}")
        if len(null_cn_rows) > 20:
            lines.append(f"  ... 외 {len(null_cn_rows) - 20}건")
        lines.append("\n해당 피처의 CN값을 [CN값 편집] 탭에서 확인·수정하세요.")
        QMessageBox.warning(self, "CN값 NULL 피처 있음", "\n".join(lines))

    def _recalc_log(self, msg: str):
        self.txtRecalcLog.append(msg)
        sb = self.txtRecalcLog.verticalScrollBar()
        sb.setValue(sb.maximum())

    # ── 유틸리티 ──────────────────────────────────────────────────────────────

    def _log(self, msg: str):
        self.txtLog.append(msg)
        sb = self.txtLog.verticalScrollBar()
        sb.setValue(sb.maximum())
