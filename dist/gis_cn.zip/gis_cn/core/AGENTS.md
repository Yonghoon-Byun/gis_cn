<!-- Parent: ../AGENTS.md -->
<!-- Generated: 2026-03-10 | Updated: 2026-03-10 -->

# core - 비즈니스 로직 모듈

## Purpose
CN값 계산기의 핵심 비즈니스 로직을 담당하는 모듈. PostGIS 연결, 공간 연산, CN값 매칭, 결과 계산/내보내기를 각 파일로 분리.

## Key Files
| File | Description |
|------|-------------|
| `__init__.py` | 빈 모듈 마커 |
| `db_manager.py` | PostGIS(Azure) 연결 및 ST_Intersection 쿼리 |
| `spatial_ops.py` | QGIS Processing 기반 공간연산 (clip, dissolve, intersection) |
| `cn_matcher.py` | CN값 조회/매칭 (pandas 기반 Excel 로드) |
| `land_use_mapper.py` | 토지이용 재분류 매핑 (JSON 로드/저장/적용) |
| `result_calculator.py` | AMC2/AMC3 계산 및 results.xlsx 내보내기 |

## For AI Agents

### Working In This Directory
- 각 파일은 독립적 모듈로, dialog.py에서 import하여 사용
- db_manager.py에 DB 접속정보 하드코딩 (DB_CONFIG)
- spatial_ops.py의 LEVEL_COLUMNS가 토지피복 분류체계 레벨 매핑

### Key Functions
- `db_manager.get_soil_lc_intersection()`: 단일 CTE 쿼리로 토양×토지피복 교차
- `cn_matcher.apply_cn_to_layer()`: CN값 일괄 적용, 실패 목록 반환
- `result_calculator.calculate_results()`: AMC2/AMC3 계산 (가중평균)
- `result_calculator._amc3()`: 논/답은 고정값 79, 나머지는 공식 적용

### Common Patterns
- `_rows_to_memory_layer()`: psycopg2 결과 → QgsVectorLayer 변환
- `_build_result_layer()`: 5개 컬럼 표준 레이어 생성 (소유역명, 토지이용, 유역면적, 토양군, cn값)
- AMC3 = 79 (논/답) or floor(23×AMC2/(10+0.13×AMC2))

### Testing Requirements
- PostGIS 연결 필수 (db_manager 테스트)
- QGIS Processing 환경 필요 (spatial_ops 테스트)
- cn_value.xlsx 파일 경로 의존 (cn_matcher)

## Dependencies

### Internal
- `../dialog.py` → 모든 core 모듈 import
- `../cn_value.xlsx` → cn_matcher.py가 기본 CN 테이블로 사용

### External
- psycopg2, pandas, openpyxl, qgis.core, processing

<!-- MANUAL: -->
