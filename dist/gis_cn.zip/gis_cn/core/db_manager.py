import psycopg2
from qgis.core import QgsVectorLayer, QgsFeature, QgsGeometry, QgsField, QgsFields
from qgis.PyQt.QtCore import QVariant
import logging

logger = logging.getLogger(__name__)

DB_CONFIG = {
    "host": "geo-spatial-hub-prod.postgres.database.azure.com",
    "port": 6432,
    "dbname": "dde-water",
    "user": "waterviewer",
    "password": "water123!@#",
}

GEOM_COLUMN = "geom"

# psycopg2 OID → QVariant 타입 매핑
_INT_OIDS = {20, 21, 23}  # int8, int2, int4
_FLOAT_OIDS = {700, 701, 1700}  # float4, float8, numeric

# level별 (코드 컬럼, 이름 컬럼) — dissolve 기준
_LC_DISSOLVE_COLS = {
    "l1": ("l1_code", "l1_name"),
    "l2": ("l2_code", "l2_name"),
    "l3": ("l3_code", "l3_name"),
}


def get_connection():
    """PostGIS DB 연결 반환"""
    return psycopg2.connect(**DB_CONFIG)


def _rows_to_memory_layer(rows, col_names, col_oids, geom_col, layer_name, srid):
    """
    psycopg2 결과 행을 QgsVectorLayer (메모리) 로 변환.
    geometry 컬럼은 ST_AsBinary()로 WKB(bytea) 형태로 전달받아야 함.
    """
    geom_idx = col_names.index(geom_col)

    fields = QgsFields()
    for name, oid in zip(col_names, col_oids):
        if name == geom_col:
            continue
        if oid in _INT_OIDS:
            fields.append(QgsField(name, QVariant.Int))
        elif oid in _FLOAT_OIDS:
            fields.append(QgsField(name, QVariant.Double))
        else:
            fields.append(QgsField(name, QVariant.String))

    uri = f"Polygon?crs=EPSG:{srid}"
    layer = QgsVectorLayer(uri, layer_name, "memory")
    provider = layer.dataProvider()
    provider.addAttributes(fields)
    layer.updateFields()

    features = []
    for row in rows:
        feat = QgsFeature(layer.fields())
        wkb = row[geom_idx]
        if wkb is not None:
            geom = QgsGeometry()
            geom.fromWkb(bytes(wkb))
            feat.setGeometry(geom)
        attr_idx = 0
        for i, name in enumerate(col_names):
            if name == geom_col:
                continue
            feat.setAttribute(attr_idx, row[i])
            attr_idx += 1
        features.append(feat)

    provider.addFeatures(features)
    layer.updateExtents()
    return layer


def get_soil_layer(polygon_geom_wkt: str, srid: int = 5186) -> QgsVectorLayer:
    """
    소유역 폴리곤으로 Clip된 토양군 레이어 반환 (PostGIS ST_Intersection 적용).
    컬럼: soil_code, hydro_type, hydro_ty_1, k
    """
    sql = """
        WITH w0 AS (
            SELECT ST_GeomFromText(%(wkt)s, %(srid)s) AS geom
        ),
        w AS (
            -- geom: 입력 좌표계(출력 교차용) / geom_n: 테이블 native 5186 상수(인덱스 사용 필터용)
            SELECT geom, ST_Transform(geom, 5186) AS geom_n FROM w0
        )
        SELECT soil_code, hydro_type, hydro_ty_1, k,
               ST_AsBinary(clipped) AS geom
        FROM (
            SELECT soil_code, hydro_type, hydro_ty_1, k,
                   ST_CollectionExtract(
                       ST_Intersection(ST_Transform(s.geom, %(srid)s), w.geom),
                       3
                   ) AS clipped
            FROM public.soil s, w
            WHERE ST_Intersects(s.geom, w.geom_n)
        ) t
        WHERE clipped IS NOT NULL
          AND NOT ST_IsEmpty(clipped)
          AND ST_Area(clipped) > 0
    """
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(sql, {"wkt": polygon_geom_wkt, "srid": srid})
        rows = cur.fetchall()
        col_names = [desc[0] for desc in cur.description]
        col_oids = [desc[1] for desc in cur.description]
        cur.close()
        conn.close()
        logger.info(f"토양군 clip: {len(rows)}개 피처")
        return _rows_to_memory_layer(
            rows, col_names, col_oids, "geom", "토양군_clip", srid
        )
    except Exception as e:
        logger.error(f"토양군 추출 오류: {e}")
        raise


def get_land_cover_layer(
    polygon_geom_wkt: str, srid: int = 5186, level: str = "l1"
) -> QgsVectorLayer:
    """
    소유역 폴리곤으로 Clip된 토지피복도 레이어 반환 (PostGIS ST_Intersection 적용).
    컬럼: gid, l1_code, l1_name, l2_code, l2_name, l3_code, l3_name
    """
    sql = """
        WITH w0 AS (
            SELECT ST_GeomFromText(%(wkt)s, %(srid)s) AS geom
        ),
        w AS (
            -- geom: 입력 좌표계(출력 교차용) / geom_n: 테이블 native 5186 상수(인덱스 사용 필터용)
            SELECT geom, ST_Transform(geom, 5186) AS geom_n FROM w0
        )
        SELECT gid, l1_code, l1_name, l2_code, l2_name, l3_code, l3_name,
               ST_AsBinary(clipped) AS geom
        FROM (
            SELECT gid, l1_code, l1_name, l2_code, l2_name, l3_code, l3_name,
                   ST_CollectionExtract(
                       ST_Intersection(ST_Transform(l.geom, %(srid)s), w.geom),
                       3
                   ) AS clipped
            FROM public.land_cover l, w
            WHERE ST_Intersects(l.geom, w.geom_n)
        ) t
        WHERE clipped IS NOT NULL
          AND NOT ST_IsEmpty(clipped)
          AND ST_Area(clipped) > 0
    """
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(sql, {"wkt": polygon_geom_wkt, "srid": srid})
        rows = cur.fetchall()
        col_names = [desc[0] for desc in cur.description]
        col_oids = [desc[1] for desc in cur.description]
        cur.close()
        conn.close()
        logger.info(f"토지피복도 clip: {len(rows)}개 피처 (level={level})")
        return _rows_to_memory_layer(
            rows, col_names, col_oids, "geom", "토지피복도_clip", srid
        )
    except Exception as e:
        logger.error(f"토지피복도 추출 오류: {e}")
        raise


def get_soil_lc_intersection(
    polygon_geom_wkt: str, srid: int = 5186, level: str = "l1"
) -> QgsVectorLayer:
    """
    PostGIS에서 토양군 × 토지피복도 Intersection 일괄 처리.
    - 소유역으로 clip
    - level 기준 토지피복도 ST_Union(Dissolve)
    - 토양군 × 토지피복도 ST_Intersection
    반환 컬럼: soil_code, hydro_type, hydro_ty_1, k, {code_col}, {name_col}
    """
    code_col, name_col = _LC_DISSOLVE_COLS[level]
    sql = f"""
        WITH w0 AS (
            SELECT ST_GeomFromText(%(wkt)s, %(srid)s) AS geom
        ),
        w AS (
            -- geom_n: 테이블 native 5186 상수(인덱스 사용 필터용)
            SELECT geom, ST_Transform(geom, 5186) AS geom_n FROM w0
        ),
        sc AS (
            SELECT soil_code, hydro_type, hydro_ty_1, k,
                   ST_CollectionExtract(
                       ST_Intersection(ST_Transform(s.geom, %(srid)s), w.geom),
                       3
                   ) AS geom
            FROM public.soil s, w
            WHERE ST_Intersects(s.geom, w.geom_n)
        ),
        sc_valid AS (
            SELECT soil_code, hydro_type, hydro_ty_1, k, geom
            FROM sc
            WHERE geom IS NOT NULL AND NOT ST_IsEmpty(geom) AND ST_Area(geom) > 0
        ),
        lc_raw AS (
            SELECT {code_col}, {name_col},
                   ST_CollectionExtract(
                       ST_Intersection(ST_Transform(l.geom, %(srid)s), w.geom),
                       3
                   ) AS geom
            FROM public.land_cover l, w
            WHERE ST_Intersects(l.geom, w.geom_n)
        ),
        lc AS (
            SELECT {code_col}, {name_col},
                   ST_Union(geom) AS geom
            FROM lc_raw
            WHERE geom IS NOT NULL AND NOT ST_IsEmpty(geom) AND ST_Area(geom) > 0
            GROUP BY {code_col}, {name_col}
        ),
        ix AS (
            SELECT sc.soil_code, sc.hydro_type, sc.hydro_ty_1, sc.k,
                   lc.{code_col}, lc.{name_col},
                   ST_CollectionExtract(ST_Intersection(sc.geom, lc.geom), 3) AS geom
            FROM sc_valid sc
            JOIN lc ON ST_Intersects(sc.geom, lc.geom)
        )
        SELECT soil_code, hydro_type, hydro_ty_1, k,
               {code_col}, {name_col},
               ST_AsBinary(geom) AS geom
        FROM ix
        WHERE geom IS NOT NULL
          AND NOT ST_IsEmpty(geom)
          AND ST_Area(geom) > 0
    """
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(sql, {"wkt": polygon_geom_wkt, "srid": srid})
        rows = cur.fetchall()
        col_names = [desc[0] for desc in cur.description]
        col_oids = [desc[1] for desc in cur.description]
        cur.close()
        conn.close()
        logger.info(f"토양군×토지피복 교차: {len(rows)}개 피처 (level={level})")
        return _rows_to_memory_layer(
            rows, col_names, col_oids, "geom", "토양군_토지피복_교차", srid
        )
    except Exception as e:
        logger.error(f"토양군×토지피복 교차 오류: {e}")
        raise


def get_all_layers(
    polygon_geom_wkt: str, srid: int = 5186, level: str = "l1"
):
    """
    단일 DB 연결로 ①토양군_clip ②토지피복도_clip ③교차분석 레이어를 한 번에 반환.
    PostgreSQL 임시 테이블을 활용해 clip 연산 중복을 제거한다.
    반환: (soil_clipped, lc_clipped, soil_lc) QgsVectorLayer 튜플
    """
    code_col, name_col = _LC_DISSOLVE_COLS[level]

    sql_soil = """
        CREATE TEMP TABLE _soil_clip ON COMMIT DROP AS
        SELECT soil_code, hydro_type, hydro_ty_1, k,
               ST_CollectionExtract(
                   ST_Intersection(ST_Transform(s.geom, %(srid)s), w.geom),
                   3
               ) AS geom
        FROM public.soil s,
             (SELECT ST_GeomFromText(%(wkt)s, %(srid)s) AS geom,
                     ST_Transform(ST_GeomFromText(%(wkt)s, %(srid)s), 5186) AS geom_n) w
        WHERE ST_Intersects(s.geom, w.geom_n)
    """

    sql_lc = f"""
        CREATE TEMP TABLE _lc_clip ON COMMIT DROP AS
        SELECT gid, l1_code, l1_name, l2_code, l2_name, l3_code, l3_name,
               ST_CollectionExtract(
                   ST_Intersection(ST_Transform(l.geom, %(srid)s), w.geom),
                   3
               ) AS geom
        FROM public.land_cover l,
             (SELECT ST_GeomFromText(%(wkt)s, %(srid)s) AS geom,
                     ST_Transform(ST_GeomFromText(%(wkt)s, %(srid)s), 5186) AS geom_n) w
        WHERE ST_Intersects(l.geom, w.geom_n)
    """

    sql_fetch_soil = """
        SELECT soil_code, hydro_type, hydro_ty_1, k,
               ST_AsBinary(geom) AS geom
        FROM _soil_clip
        WHERE geom IS NOT NULL AND NOT ST_IsEmpty(geom) AND ST_Area(geom) > 0
    """

    sql_fetch_lc = """
        SELECT gid, l1_code, l1_name, l2_code, l2_name, l3_code, l3_name,
               ST_AsBinary(geom) AS geom
        FROM _lc_clip
        WHERE geom IS NOT NULL AND NOT ST_IsEmpty(geom) AND ST_Area(geom) > 0
    """

    sql_intersect = f"""
        WITH lc_dissolved AS (
            SELECT {code_col}, {name_col},
                   ST_Union(geom) AS geom
            FROM _lc_clip
            WHERE geom IS NOT NULL AND NOT ST_IsEmpty(geom) AND ST_Area(geom) > 0
            GROUP BY {code_col}, {name_col}
        ),
        sc_valid AS (
            SELECT soil_code, hydro_type, hydro_ty_1, k, geom
            FROM _soil_clip
            WHERE geom IS NOT NULL AND NOT ST_IsEmpty(geom) AND ST_Area(geom) > 0
        ),
        ix AS (
            SELECT sc.soil_code, sc.hydro_type, sc.hydro_ty_1, sc.k,
                   lc.{code_col}, lc.{name_col},
                   ST_CollectionExtract(ST_Intersection(sc.geom, lc.geom), 3) AS geom
            FROM sc_valid sc
            JOIN lc_dissolved lc ON ST_Intersects(sc.geom, lc.geom)
        )
        SELECT soil_code, hydro_type, hydro_ty_1, k,
               {code_col}, {name_col},
               ST_AsBinary(geom) AS geom
        FROM ix
        WHERE geom IS NOT NULL AND NOT ST_IsEmpty(geom) AND ST_Area(geom) > 0
    """

    params = {"wkt": polygon_geom_wkt, "srid": srid}
    try:
        conn = get_connection()
        cur = conn.cursor()

        cur.execute(sql_soil, params)
        cur.execute(sql_lc, params)

        cur.execute(sql_fetch_soil)
        soil_rows = cur.fetchall()
        soil_col_names = [desc[0] for desc in cur.description]
        soil_col_oids = [desc[1] for desc in cur.description]

        cur.execute(sql_fetch_lc)
        lc_rows = cur.fetchall()
        lc_col_names = [desc[0] for desc in cur.description]
        lc_col_oids = [desc[1] for desc in cur.description]

        cur.execute(sql_intersect)
        ix_rows = cur.fetchall()
        ix_col_names = [desc[0] for desc in cur.description]
        ix_col_oids = [desc[1] for desc in cur.description]

        cur.close()
        conn.close()

        logger.info(f"[단일연결] 토양군 clip: {len(soil_rows)}개, 토지피복 clip: {len(lc_rows)}개, 교차: {len(ix_rows)}개 (level={level})")

        soil_layer = _rows_to_memory_layer(soil_rows, soil_col_names, soil_col_oids, "geom", "토양군_clip", srid)
        lc_layer = _rows_to_memory_layer(lc_rows, lc_col_names, lc_col_oids, "geom", "토지피복도_clip", srid)
        ix_layer = _rows_to_memory_layer(ix_rows, ix_col_names, ix_col_oids, "geom", "토양군_토지피복_교차", srid)

        return soil_layer, lc_layer, ix_layer
    except Exception as e:
        logger.error(f"get_all_layers 오류: {e}")
        raise
